package com.chacha.ebook

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private data class TocItem(val title:String,val chapter:Int)
    private data class Chapter(val title:String,val text:String)
    private data class Book(var title:String,var author:String,val text:String,val chapters:List<Chapter> = emptyList(),val toc:List<TocItem> = emptyList(),val cover:ByteArray? = null,val marks:MutableList<String> = mutableListOf(),val notes:MutableList<String> = mutableListOf())
    private lateinit var root:LinearLayout
    private lateinit var tts:TextToSpeech
    private var web:WebView?=null
    private val books= mutableListOf<Book>()
    private var current=-1
    private var currentChapter=0
    private var font=19
    private var line=1.9
    private var pageMode=false
    private var darkMode=false
    private var auto=false
    private val handler=Handler(Looper.getMainLooper())
    private val autoTask=object:Runnable{override fun run(){if(auto){web?.scrollBy(0,2);handler.postDelayed(this,45)}}}
    private val paper=Color.rgb(249,247,241)
    private val ink=Color.rgb(48,45,42)
    private val muted=Color.rgb(139,132,123)
    private val accent=Color.rgb(126,105,88)
    private val dark=Color.rgb(35,35,37)
    private val pick=100
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);tts=TextToSpeech(this,this);root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};setContentView(root);showShelf()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun label(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold)setTypeface(typeface,Typeface.BOLD)}
    private fun bg(color:Int,r:Int=12)=GradientDrawable().apply{setColor(color);cornerRadius=dp(r).toFloat()}
    private fun button(s:String,action:()->Unit)=TextView(this).apply{text=s;textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setPadding(dp(5),dp(12),dp(5),dp(12));background=bg(dark,10);setOnClickListener{action()}}
    private fun add(parent:LinearLayout,v:View,h:Int=ViewGroup.LayoutParams.WRAP_CONTENT){parent.addView(v,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,h))}
    private fun showShelf(){auto=false;handler.removeCallbacks(autoTask);web?.destroy();web=null;root.removeAllViews();root.setPadding(dp(18),dp(20),dp(18),dp(12));root.setBackgroundColor(Color.rgb(246,246,246));val top=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL};val title=LinearLayout(this).apply{orientation=1};title.addView(label("차차의 서재",25f,ink,true));title.addView(label("나만의 전자책 공간",12f,muted));top.addView(title,LinearLayout.LayoutParams(0,-2,1f));top.addView(button("＋ 책 추가"){chooseBook()});add(root,top);add(root,label("내 책  ${books.size}권",13f,muted,true).apply{setPadding(0,dp(24),0,dp(12))});val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=1};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));if(books.isEmpty())list.addView(label("아직 책이 없어요\nEPUB 또는 TXT 파일을 추가해 보세요.",16f,muted).apply{gravity=Gravity.CENTER;setPadding(0,dp(90),0,0)})
        books.forEachIndexed{i,b->val row=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(10),dp(10),dp(10));background=bg(Color.WHITE,14)};val coverBytes=b.cover;val coverView:View=if(coverBytes!=null){val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;setImageBitmap(BitmapFactory.decodeByteArray(coverBytes,0,coverBytes.size))};iv}else label("BOOK\n✦",12f,Color.WHITE,true).apply{gravity=Gravity.CENTER;background=bg(intArrayOf(0xff8d8176.toInt(),0xff788575.toInt(),0xff88777b.toInt())[i%3],8)};row.addView(coverView,LinearLayout.LayoutParams(dp(62),dp(86)));val info=LinearLayout(this).apply{orientation=1;setPadding(dp(12),0,0,0)};info.addView(label(b.title,15f,ink,true));info.addView(label(b.author,12f,muted).apply{setPadding(0,dp(5),0,0)});info.addView(label("책갈피 ${b.marks.size}개",11f,accent).apply{setPadding(0,dp(8),0,0)});row.addView(info,LinearLayout.LayoutParams(0,-2,1f));row.setOnClickListener{openBook(i)};row.setOnLongClickListener{editBook(i);true};val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);list.addView(row,lp)}
    }
    private fun editBook(i:Int){val b=books[i];val box=LinearLayout(this).apply{orientation=1;setPadding(dp(20),0,dp(20),0)};val t=EditText(this).apply{setText(b.title);hint="책 제목"};val a=EditText(this).apply{setText(b.author);hint="작가명"};box.addView(t);box.addView(a);AlertDialog.Builder(this).setTitle("책 정보 수정").setView(box).setPositiveButton("저장"){_,_->b.title=t.text.toString();b.author=a.text.toString();showShelf()}.setNegativeButton("취소",null).show()}
    private fun chooseBook(){val it=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/epub+zip","text/plain","application/octet-stream"))};startActivityForResult(it,pick)}
    @Deprecated("Deprecated") override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r!=pick||c!=RESULT_OK)return;val u=d?.data?:return;try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};val n=contentResolver.query(u,null,null,null,null)?.use{x->val k=x.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(x.moveToFirst()&&k>=0)x.getString(k) else "새 책"}?:"새 책";if(n.lowercase().endsWith(".epub")){val b=readEpub(u,n.substringBeforeLast('.'));books.add(0,b)}else{val txt=contentResolver.openInputStream(u)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:"파일을 읽을 수 없습니다.";books.add(0,Book(n.substringBeforeLast('.'),"작가명",txt))};openBook(0)}
    private fun parseXml(s:String)=DocumentBuilderFactory.newInstance().apply{isNamespaceAware=true}.newDocumentBuilder().parse(s.byteInputStream())
    private fun attr(e:Element,name:String)=e.getAttribute(name).ifBlank{e.getAttributeNS("http://www.idpf.org/2007/opf",name)}
    private fun textOf(html:String):String=html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>")," ").replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>"),"\n\n").replace(Regex("<[^>]+>")," ").replace("&nbsp;"," ").replace("&#160;"," ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace(Regex("[ \\t]+")," ").trim()
    private fun readEpub(uri:Uri,fallback:String):Book{
        val files=mutableMapOf<String,ByteArray>();contentResolver.openInputStream(uri)?.use{raw->ZipInputStream(raw).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory)files[e.name]=z.readBytes();z.closeEntry();e=z.nextEntry}}}
        fun str(path:String)=files[path]?.toString(Charsets.UTF_8).orEmpty()
        val container=parseXml(str("META-INF/container.xml"));val rootfiles=container.getElementsByTagName("rootfile");val opfPath=(rootfiles.item(0) as? Element)?.getAttribute("full-path")?:"";val opf=parseXml(str(opfPath));val metadata=opf.getElementsByTagName("metadata").item(0) as? Element
        fun meta(tag:String)=metadata?.getElementsByTagName(tag)?.item(0)?.textContent?.trim().orEmpty()
        val title=meta("dc:title").ifBlank{fallback};val author=meta("dc:creator").ifBlank{"작가명"};val manifest=mutableMapOf<String,Pair<String,String>>();val items=opf.getElementsByTagName("item");for(i in 0 until items.length){val el=items.item(i) as Element;manifest[attr(el,"id")]=attr(el,"href") to attr(el,"properties")}
        val base=opfPath.substringBeforeLast('/',"");fun resolve(href:String):String{val raw=href.substringBefore('#').substringBefore('?');val joined=if(raw.startsWith("/"))raw.trimStart('/') else if(base.isBlank())raw else "$base/$raw";val stack=mutableListOf<String>();joined.split('/').forEach{when(it){".."->if(stack.isNotEmpty())stack.removeAt(stack.lastIndex);".",""->{};else->stack.add(it)}};return stack.joinToString("/")}
        val spine=opf.getElementsByTagName("itemref");val chapters=mutableListOf<Chapter>();val hrefToIndex=mutableMapOf<String,Int>();for(i in 0 until spine.length){val id=attr(spine.item(i) as Element,"idref");val item=manifest[id]?:continue;val path=resolve(item.first);val body=textOf(str(path));if(body.isNotBlank()){hrefToIndex[path]=chapters.size;chapters.add(Chapter(body.lineSequence().firstOrNull()?.take(50)?.ifBlank{"제목 없음"}?:"제목 없음",body))}}
        val toc=mutableListOf<TocItem>();val navEntry=manifest.values.firstOrNull{it.second.split(' ').contains("nav")};if(navEntry!=null){val navPath=resolve(navEntry.first);val navDoc=parseXml(str(navPath));val links=navDoc.getElementsByTagName("a");for(i in 0 until links.length){val a=links.item(i) as Element;val target=resolveRelative(navPath,a.getAttribute("href"),base);val idx=hrefToIndex[target]?:continue;val name=a.textContent.trim();if(name.isNotBlank())toc.add(TocItem(name,idx))}}
        if(toc.isEmpty()){val ncx=manifest.values.firstOrNull{it.first.endsWith(".ncx",true)};if(ncx!=null){val path=resolve(ncx.first);val doc=parseXml(str(path));val points=doc.getElementsByTagName("navPoint");for(i in 0 until points.length){val p=points.item(i) as Element;val label=p.getElementsByTagName("text").item(0)?.textContent?.trim().orEmpty();val src=(p.getElementsByTagName("content").item(0) as? Element)?.getAttribute("src")?:continue;val target=resolveRelative(path,src,base);val idx=hrefToIndex[target]?:continue;if(label.isNotBlank())toc.add(TocItem(label,idx))}}}
        val coverId=metadata?.getElementsByTagName("meta")?.let{nodes->(0 until nodes.length).map{nodes.item(it) as Element}.firstOrNull{it.getAttribute("name")=="cover"}?.getAttribute("content")}.orEmpty();val coverItem=manifest[coverId]?.first?.let{resolve(it)}?:manifest.values.firstOrNull{it.second.split(' ').contains("cover-image")}?.first?.let{resolve(it)};val cover=coverItem?.let{files[it]};val full=chapters.joinToString("\n\n"){it.text}.ifBlank{"EPUB 본문을 찾지 못했습니다."};return Book(title,author,full,chapters,toc,cover)
    }
    private fun resolveRelative(documentPath:String,href:String,base:String):String{val rel=href.substringBefore('#').substringBefore('?');val parent=documentPath.substringBeforeLast('/',"");val joined=if(rel.startsWith("/"))rel.trimStart('/') else if(parent.isBlank())rel else "$parent/$rel";val st=mutableListOf<String>();joined.split('/').forEach{when(it){".."->if(st.isNotEmpty())st.removeAt(st.lastIndex);".",""->{};else->st.add(it)}};return st.joinToString("/")}
    private fun openBook(i:Int){if(i !in books.indices)return;current=i;currentChapter=0;root.removeAllViews();root.setPadding(0,0,0,0);root.setBackgroundColor(if(darkMode)dark else paper);val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8))};top.addView(button("‹ 뒤로"){showShelf()},LinearLayout.LayoutParams(0,-2,1f));top.addView(button("검색"){search()},LinearLayout.LayoutParams(0,-2,1f));top.addView(button("책갈피＋"){bookmark()},LinearLayout.LayoutParams(0,-2,1f));add(root,top);val w=WebView(this).apply{setBackgroundColor(if(darkMode)dark else paper);settings.javaScriptEnabled=false;isVerticalScrollBarEnabled=false};web=w;root.addView(w,LinearLayout.LayoutParams(-1,0,1f));render();val bar=LinearLayout(this).apply{orientation=0;setPadding(dp(4),dp(7),dp(4),dp(7));setBackgroundColor(Color.rgb(35,35,37))};val actions=listOf("목차","TTS","자동\n스크롤","독서노트","보기\n설정","뷰어\n설정");actions.forEachIndexed{n,s->bar.addView(button(s){when(n){0->toc();1->speak();2->toggleAuto();3->notes();4->viewSettings();5->readerSettings()}},LinearLayout.LayoutParams(0,-2,1f))};add(root,bar)}
    private fun render(){val b=books.getOrNull(current)?:return;val chapter=b.chapters.getOrNull(currentChapter);val content=chapter?.text?:b.text;val paras=content.split(Regex("\\n\\s*\\n")).filter{it.isNotBlank()}.map{ "<p>${esc(it).replace("\n","<br>")}</p>" }.joinToString("");val mode=if(pageMode)"column-width:88vw;column-gap:10vw;" else "column-width:auto;";val background=if(darkMode)"#232325" else "#F9F7F1";val foreground=if(darkMode)"#E7E3DC" else "#393630";val html="""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>*{box-sizing:border-box}html,body{margin:0;background:$background;color:$foreground}body{font-family:serif;font-size:${font}px;line-height:$line;padding:30px 24px 55px;word-break:keep-all;overflow-wrap:anywhere;$mode}h2{font-size:1.1em;margin:0 0 2em}p{margin:0 0 1.6em;text-align:justify}</style></head><body>${if(chapter!=null)"<h2>${esc(chapter.title)}</h2>" else ""}$paras</body></html>""";web?.setBackgroundColor(if(darkMode)dark else paper);web?.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun bookmark(){val b=books.getOrNull(current)?:return;b.marks.add("${b.chapters.getOrNull(currentChapter)?.title?:"책갈피"} · ${b.title}");Toast.makeText(this,"책갈피에 추가했어요",Toast.LENGTH_SHORT).show()}
    private fun search(){val e=EditText(this).apply{hint="검색할 내용"};AlertDialog.Builder(this).setTitle("책 속 내용 검색").setView(e).setPositiveButton("검색"){_,_->web?.findAllAsync(e.text.toString())}.setNegativeButton("취소",null).show()}
    private fun toc(){val b=books.getOrNull(current)?:return;val items=if(b.toc.isNotEmpty())b.toc else b.chapters.mapIndexed{idx,ch->TocItem(ch.title,idx)};if(items.isEmpty()){Toast.makeText(this,"목차가 없습니다.",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("목차 목록").setItems(items.map{it.title}.toTypedArray()){_,which->currentChapter=items[which].chapter;render();web?.scrollTo(0,0)}.setNegativeButton("닫기",null).show()}
    private fun notes(){val b=books.getOrNull(current)?:return;val all=(b.marks+b.notes).toTypedArray();AlertDialog.Builder(this).setTitle("독서노트 · 전체 ${all.size}개").setItems(all.ifEmpty{arrayOf("저장된 내용이 없습니다.")}){_,_->}.setPositiveButton("메모 추가"){_,_->val e=EditText(this).apply{hint="메모를 입력하세요"};AlertDialog.Builder(this).setTitle("독서 메모").setView(e).setPositiveButton("저장"){_,_->b.notes.add(e.text.toString());Toast.makeText(this,"메모를 저장했어요",Toast.LENGTH_SHORT).show()}.setNegativeButton("취소",null).show()}.setNegativeButton("닫기",null).show()}
    private fun speak(){val s=books.getOrNull(current)?.chapters?.getOrNull(currentChapter)?.text?:books.getOrNull(current)?.text.orEmpty();if(s.isNotBlank())tts.speak(s.take(5000),TextToSpeech.QUEUE_FLUSH,null,"reader")}
    private fun toggleAuto(){auto=!auto;if(auto)handler.post(autoTask)else handler.removeCallbacks(autoTask);Toast.makeText(this,if(auto)"자동 스크롤 켜짐" else "자동 스크롤 꺼짐",Toast.LENGTH_SHORT).show()}
    private fun viewSettings(){val opts=arrayOf("페이지 넘김","세로 스크롤");AlertDialog.Builder(this).setTitle("읽기 방식").setSingleChoiceItems(opts,if(pageMode)0 else 1){d,n->pageMode=n==0;render();d.dismiss()}.show()}
    private fun readerSettings(){val opts=arrayOf("글자 크기 줄이기","글자 크기 키우기","줄 간격 변경",if(darkMode)"아이보리 모드로 전환" else "다크모드로 전환");AlertDialog.Builder(this).setTitle("보기 설정").setItems(opts){_,n->when(n){0->font=(font-1).coerceAtLeast(14);1->font=(font+1).coerceAtMost(32);2->line=if(line<2.0)2.2 else 1.7;3->{darkMode=!darkMode;root.setBackgroundColor(if(darkMode)dark else paper)}};render()}.show()}
    override fun onBackPressed(){if(web!=null)showShelf()else super.onBackPressed()}
    override fun onInit(s:Int){if(s==TextToSpeech.SUCCESS)tts.language=Locale.KOREAN}
    override fun onDestroy(){auto=false;handler.removeCallbacks(autoTask);web?.destroy();tts.stop();tts.shutdown();super.onDestroy()}
}
