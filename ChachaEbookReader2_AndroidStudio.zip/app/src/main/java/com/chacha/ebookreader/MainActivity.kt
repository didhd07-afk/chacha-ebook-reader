package com.chacha.ebookreader

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.Base64
import android.util.Xml
import android.webkit.*
import android.widget.*
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.*
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("library_v2", MODE_PRIVATE) }
    private val books = mutableListOf<Book>()
    private var currentBook: Book? = null
    private var web: WebView? = null
    private val PICK_BOOK = 41

    data class Book(
        val id: String,
        var title: String,
        val fileName: String,
        var cover: String = "",
        var format: String = "TXT"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadBooks()
        showLibrary()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.KOREAN
    }

    private fun loadBooks() {
        books.clear()
        val arr = try { JSONArray(prefs.getString("books", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            books.add(Book(o.optString("id"), o.optString("title"), o.optString("file"),
                o.optString("cover"), o.optString("format", "TXT")))
        }
    }

    private fun saveBooks() {
        val arr = JSONArray()
        books.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title)
                .put("file", it.fileName).put("cover", it.cover).put("format", it.format))
        }
        prefs.edit().putString("books", arr.toString()).apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun baseScreen(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(249, 248, 246))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = 21f
            setTextColor(Color.rgb(38, 37, 42))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        setContentView(root)
        return root
    }

    private fun showLibrary() {
        web = null
        currentBook = null
        val screen = baseScreen("차차의 서재")
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        top.addView(TextView(this).apply {
            text = "내 책 ${books.size}권"
            textSize = 14f
            setTextColor(Color.GRAY)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply {
            text = "+ 책 추가"
            setOnClickListener { chooseBook() }
        })
        screen.addView(top)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(24))
        }
        if (books.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "아직 책이 없어요.\n[+ 책 추가]를 눌러 EPUB 또는 TXT 파일을 넣어주세요."
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(130, 126, 120))
                setPadding(dp(24), dp(90), dp(24), dp(90))
            })
        }
        books.forEach { book -> list.addView(bookRow(book)) }
        scroll.addView(list)
        screen.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun bookRow(book: Book): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        val cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(237, 234, 230))
            if (book.cover.isNotBlank()) {
                try {
                    val bytes = Base64.decode(book.cover, Base64.DEFAULT)
                    setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                } catch (_: Exception) {}
            } else {
                setImageResource(android.R.drawable.ic_menu_agenda)
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }
        }
        card.addView(cover, LinearLayout.LayoutParams(dp(72), dp(100)))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(4), 0)
        }
        info.addView(TextView(this).apply {
            text = book.title
            textSize = 16f
            maxLines = 2
            setTextColor(Color.rgb(42, 40, 45))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        info.addView(TextView(this).apply {
            text = book.format
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, dp(4), 0, dp(6))
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(smallButton("읽기") { openBook(book) })
        actions.addView(smallButton("제목") { renameBook(book) })
        actions.addView(smallButton("삭제") { deleteBook(book) })
        info.addView(actions)
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(10))
            addView(card)
        }
        return wrap
    }

    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        minWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { action() }
    }

    private fun renameBook(book: Book) {
        val edit = EditText(this).apply { setText(book.title); selectAll() }
        AlertDialog.Builder(this).setTitle("책 제목 변경").setView(edit)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                val newTitle = edit.text.toString().trim()
                if (newTitle.isNotEmpty()) {
                    book.title = newTitle
                    saveBooks()
                    showLibrary()
                }
            }.show()
    }

    private fun deleteBook(book: Book) {
        AlertDialog.Builder(this).setTitle("책 삭제")
            .setMessage("'${book.title}'을(를) 책장에서 삭제할까요?")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                File(filesDir, book.fileName).delete()
                books.remove(book)
                saveBooks()
                showLibrary()
            }.show()
    }

    private fun chooseBook() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream"))
        }
        startActivityForResult(i, PICK_BOOK)
    }

    @Deprecated("Deprecated API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_BOOK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                val name = getDisplayName(uri) ?: "새 책.txt"
                val epub = name.endsWith(".epub", true) || (bytes.size > 1 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte())
                val id = UUID.randomUUID().toString()
                val fileName = "$id.html"
                val parsed = if (epub) parseEpub(bytes) else ParsedBook(txtToHtml(String(bytes, Charsets.UTF_8)), "", "")
                File(filesDir, fileName).writeText(parsed.html, Charsets.UTF_8)
                val book = Book(id, name.substringBeforeLast('.', name), fileName, parsed.cover, if (epub) "EPUB" else "TXT")
                books.add(book)
                saveBooks()
                showLibrary()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "파일을 추가하지 못했습니다: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun getDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    data class ParsedBook(val html: String, val cover: String, val toc: String)

    private fun txtToHtml(text: String): String =
        text.split(Regex("\\r?\\n")).joinToString("") { line ->
            if (line.isBlank()) "<div class='blank'></div>" else "<p>${escape(line)}</p>"
        }

    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun parseEpub(bytes: ByteArray): ParsedBook {
        val entries = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory) {
                    val out = ByteArrayOutputStream()
                    zip.copyTo(out)
                    entries[e.name] = out.toByteArray()
                }
                zip.closeEntry()
            }
        }
        val container = entries["META-INF/container.xml"]?.toString(Charsets.UTF_8) ?: ""
        val c = Xml.newPullParser()
        c.setInput(container.reader())
        var opfPath = ""
        while (c.next() != XmlPullParser.END_DOCUMENT) {
            if (c.eventType == XmlPullParser.START_TAG && c.name == "rootfile") {
                opfPath = c.getAttributeValue(null, "full-path") ?: ""
                break
            }
        }
        if (opfPath.isBlank()) return ParsedBook(fallbackHtml(entries), findCover(entries), "")
        val opf = entries[opfPath]?.toString(Charsets.UTF_8) ?: return ParsedBook(fallbackHtml(entries), findCover(entries), "")
        val base = opfPath.substringBeforeLast('/', "")
        val manifest = linkedMapOf<String, String>()
        val spine = mutableListOf<String>()
        val p = Xml.newPullParser()
        p.setInput(opf.reader())
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG) when (p.name) {
                "item" -> {
                    val id = p.getAttributeValue(null, "id")
                    val href = p.getAttributeValue(null, "href")
                    if (id != null && href != null) manifest[id] = normalize("$base/$href")
                }
                "itemref" -> p.getAttributeValue(null, "idref")?.let { spine.add(it) }
            }
        }
        val chapters = spine.mapNotNull { manifest[it]?.let { path -> entries[path] } }
            .map { it.toString(Charsets.UTF_8) }
        val joined = chapters.joinToString("\n<div class='chapter-break'></div>\n")
        val cover = findCover(entries)
        return ParsedBook(joined.ifBlank { fallbackHtml(entries) }, cover, "")
    }

    private fun findCover(entries: Map<String, ByteArray>): String {
        val candidate = entries.entries.firstOrNull {
            val n = it.key.lowercase()
            (n.contains("cover") && (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp"))) ||
            (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")) && n.contains("image")
        } ?: return ""
        return try { Base64.encodeToString(candidate.value, Base64.NO_WRAP) } catch (_: Exception) { "" }
    }

    private fun fallbackHtml(entries: Map<String, ByteArray>): String =
        entries.filterKeys { it.endsWith(".xhtml", true) || it.endsWith(".html", true) }
            .toSortedMap().values.joinToString("\n") { it.toString(Charsets.UTF_8) }

    private fun normalize(path: String): String {
        val parts = mutableListOf<String>()
        path.split("/").forEach {
            when (it) { "", "." -> Unit; ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex); else -> parts.add(it) }
        }
        return parts.joinToString("/")
    }

    private fun openBook(book: Book) {
        currentBook = book
        val content = try { File(filesDir, book.fileName).readText(Charsets.UTF_8) } catch (_: Exception) { "" }
        val screen = baseScreen(book.title)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
        }
        fun tool(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply { text = label; textSize = 11f; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        tool("목차") { web?.evaluateJavascript("showToc()", null) }
        tool("책갈피") { web?.evaluateJavascript("showBookmarks()", null) }
        tool("형광펜") { web?.evaluateJavascript("highlightSelection()", null) }
        tool("읽기") { web?.evaluateJavascript("speakSelectionOrPage()", null) }
        tool("설정") { showSettings() }
        screen.addView(bar)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.defaultTextEncodingName = "UTF-8"
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Native")
            setBackgroundColor(Color.rgb(250, 249, 247))
        }
        screen.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
        }
        fun nav(label: String, js: String) {
            bottom.addView(Button(this).apply { text = label; setOnClickListener { web?.evaluateJavascript(js, null) } },
                LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        nav("이전", "turnPage(-1)")
        nav("스크롤", "setMode('scroll')")
        nav("페이지", "setMode('page')")
        nav("다음", "turnPage(1)")
        screen.addView(bottom)
        val pos = prefs.getInt("position_${book.id.replace("-", "")}", 0)
        web?.loadDataWithBaseURL("https://reader.local/", readerHtml(content, book.id, pos), "text/html", "UTF-8", null)
    }

    private fun showSettings() {
        val options = arrayOf("글자 크게", "글자 작게", "줄 간격 넓게", "줄 간격 좁게", "글꼴 바꾸기", "자동 스크롤 시작/정지", "자동 스크롤 느리게", "자동 스크롤 빠르게")
        AlertDialog.Builder(this).setTitle("읽기 설정").setItems(options) { _, which ->
            val scripts = arrayOf("fontSize(1)", "fontSize(-1)", "lineSpace(0.15)", "lineSpace(-0.15)", "cycleFont()", "toggleAuto()", "autoSpeed(-1)", "autoSpeed(1)")
            web?.evaluateJavascript(scripts[which], null)
        }.show()
    }

    private fun readerHtml(content: String, id: String, pos: Int): String {
        val safeId = id.replace("-", "")
        return """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;background:#faf9f7;color:#292824}
body{font-family:serif;font-size:19px;line-height:1.9;word-break:keep-all}
#reader{padding:30px 24px 100px;max-width:760px;margin:auto}
p{margin:0 0 1.15em;text-indent:1em}
img{max-width:100%;height:auto}
h1,h2,h3{line-height:1.5;margin:1.6em 0 .8em}
.blank{height:1.1em}.chapter-break{height:20px;border-top:1px solid #ddd;margin:30px 0}
#panel{display:none;position:fixed;inset:0;background:#0008;z-index:5}
#panel>div{background:#fff;color:#333;position:absolute;right:0;top:0;bottom:0;width:82%;overflow:auto;padding:24px}
#panel button{display:block;width:100%;text-align:left;margin:6px 0;padding:12px}
body.page{overflow:hidden}
body.page #reader{max-width:none;height:100vh;overflow:visible;column-width:calc(100vw - 48px);column-gap:48px;padding:28px 24px}
body.dark,body.dark #reader{background:#202124;color:#ddd}
mark{background:#ffe58a;color:#302a20}
.tocTitle{font-weight:bold;font-size:20px}
</style></head><body><main id="reader">$content</main>
<div id="panel"><div><button onclick="closePanel()">닫기</button><div id="panelBody"></div></div></div>
<script>
const bookId='$safeId'; let mode='scroll',font=19,line=1.9,page=0,autoTimer=null,autoStep=1,fonts=['serif','sans-serif','Georgia','monospace'],fontIndex=0;
const reader=document.getElementById('reader');
function save(){Native.savePosition(bookId,Math.round(window.scrollY),page,mode);}
window.addEventListener('scroll',()=>{if(mode==='scroll')save()});
function fontSize(n){font=Math.max(13,Math.min(34,font+n));document.body.style.fontSize=font+'px';}
function lineSpace(n){line=Math.max(1.2,Math.min(2.8,line+n));document.body.style.lineHeight=line;}
function cycleFont(){fontIndex=(fontIndex+1)%fonts.length;document.body.style.fontFamily=fonts[fontIndex];}
function setMode(m){mode=m;document.body.classList.toggle('page',m==='page');if(m==='page'){page=0;reader.style.transform='translateX(0)';}else{reader.style.transform='none';window.scrollTo(0,0);}save();}
function turnPage(n){if(mode!=='page'){window.scrollBy({top:n*window.innerHeight*.85,behavior:'smooth'});return;}
 const width=window.innerWidth; const max=Math.max(0,Math.ceil(reader.scrollWidth/width)-1);page=Math.max(0,Math.min(max,page+n));reader.style.transform='translateX('+(-page*width)+'px)';save();}
function toggleAuto(){if(autoTimer){clearInterval(autoTimer);autoTimer=null;}else{autoTimer=setInterval(()=>{if(mode==='page')turnPage(1);else window.scrollBy(0,autoStep);},80);}}
function autoSpeed(n){autoStep=Math.max(1,Math.min(12,autoStep+n));}
function showPanel(html){document.getElementById('panelBody').innerHTML=html;document.getElementById('panel').style.display='block';}
function closePanel(){document.getElementById('panel').style.display='none';}
function showToc(){let hs=[...reader.querySelectorAll('h1,h2,h3')];let html='<div class="tocTitle">목차</div>';if(!hs.length)html+='<p>이 EPUB에서 제목 목차를 찾지 못했습니다.</p>';hs.forEach((h,i)=>{let id='ch'+i;h.id=id;html+='<button onclick="goTo(\\''+id+'\\')">'+h.innerText+'</button>';});showPanel(html);}
function goTo(id){closePanel();let el=document.getElementById(id);if(el){if(mode==='page'){page=Math.floor(el.offsetLeft/window.innerWidth);reader.style.transform='translateX('+(-page*window.innerWidth)+'px)';}else el.scrollIntoView();save();}}
function addBookmark(){let y=mode==='page'?page:Math.round(window.scrollY);let arr=JSON.parse(localStorage.getItem('bm_'+bookId)||'[]');arr.push(y);localStorage.setItem('bm_'+bookId,JSON.stringify(arr));alert('책갈피를 저장했습니다.');}
function showBookmarks(){let arr=JSON.parse(localStorage.getItem('bm_'+bookId)||'[]');showPanel('<div class="tocTitle">책갈피</div><button onclick="addBookmark();showBookmarks()">+ 현재 위치 저장</button>'+arr.map((v,i)=>'<button onclick="jumpBookmark('+v+')">책갈피 '+(i+1)+'</button>').join(''));}
function jumpBookmark(v){closePanel();if(mode==='page'){page=v;reader.style.transform='translateX('+(-page*window.innerWidth)+'px)';}else window.scrollTo(0,v);save();}
function highlightSelection(){let s=window.getSelection();if(!s||s.isCollapsed){alert('먼저 문장을 길게 눌러 선택하세요.');return;}try{let r=s.getRangeAt(0);let mark=document.createElement('mark');r.surroundContents(mark);let saved=reader.innerHTML;localStorage.setItem('hl_'+bookId,saved);s.removeAllRanges();}catch(e){alert('여러 문단에 걸친 선택은 한 문단씩 표시해 주세요.');}}
function speakSelectionOrPage(){let s=window.getSelection().toString();if(!s)s=reader.innerText.slice(0,4500);Native.speak(s);}
function restore(){let saved=Native.getPosition(bookId);if(saved>=0){if(mode==='page'){page=saved;reader.style.transform='translateX('+(-page*window.innerWidth)+'px)';}else window.scrollTo(0,saved);}}
let marked=localStorage.getItem('hl_'+bookId);if(marked){reader.innerHTML=marked;}
setTimeout(restore,250);
</script></body></html>
""".trimIndent()
    }

    inner class Bridge {
        @JavascriptInterface fun savePosition(id: String, y: Int, page: Int, mode: String) {
            val value = if (mode == "page") page else y
            prefs.edit().putInt("position_$id", value).apply()
        }
        @JavascriptInterface fun getPosition(id: String): Int = prefs.getInt("position_$id", 0)
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread {
                if (ttsReady) {
                    tts.stop()
                    tts.speak(text.take(4500), TextToSpeech.QUEUE_FLUSH, null, "reader_tts")
                } else Toast.makeText(this@MainActivity, "음성 엔진을 준비하고 있습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        if (web != null) showLibrary() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
