package com.chacha.ebook

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.zip.ZipInputStream

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private data class Book(val title: String, val text: String)

    private lateinit var root: LinearLayout
    private lateinit var tts: TextToSpeech
    private var web: WebView? = null
    private val books = mutableListOf<Book>()
    private var currentBook = -1
    private var fontSize = 19
    private var lineHeight = 1.95
    private val pickCode = 100

    private val ink = Color.rgb(48, 45, 42)
    private val muted = Color.rgb(139, 132, 123)
    private val paper = Color.rgb(249, 247, 241)
    private val card = Color.rgb(255, 254, 250)
    private val accent = Color.rgb(126, 105, 88)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = paper
        window.navigationBarColor = paper
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        tts = TextToSpeech(this, this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(paper)
        }
        setContentView(root)
        showShelf()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun vertical(parent: LinearLayout, view: View, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        parent.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun rounded(color: Int, radius: Int = 14, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun action(label: String, filled: Boolean = false, onClick: () -> Unit): TextView = text(label, 14f, if (filled) Color.WHITE else accent, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(11), dp(16), dp(11))
        background = rounded(if (filled) accent else Color.TRANSPARENT, 12, if (filled) null else Color.rgb(226, 220, 211))
        setOnClickListener { onClick() }
    }

    private fun showShelf() {
        web?.destroy()
        web = null
        root.removeAllViews()
        root.setPadding(dp(22), dp(18), dp(22), dp(12))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(text("차차의 서재", 25f, ink, true))
        heading.addView(text("나만의 작은 책장", 13f, muted).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(action("＋ 책 추가", true) { chooseBook() })
        vertical(root, top)

        val summary = text("내 책  ${books.size}권", 13f, muted, true).apply { setPadding(0, dp(30), 0, dp(14)) }
        vertical(root, summary)

        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        vertical(root, scroll, 0)
        (scroll.layoutParams as LinearLayout.LayoutParams).weight = 1f

        if (books.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(70), dp(20), dp(70))
            }
            empty.addView(text("▤", 48f, Color.rgb(190, 177, 160)).apply { gravity = Gravity.CENTER })
            empty.addView(text("아직 책이 없어요", 18f, ink, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(7)) })
            empty.addView(text("읽고 싶은 EPUB 또는 TXT 파일을 추가해 보세요.", 13f, muted).apply { gravity = Gravity.CENTER })
            list.addView(empty)
        } else {
            books.forEachIndexed { index, book ->
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                    background = rounded(card, 16, Color.rgb(239, 235, 227))
                    elevation = dp(1).toFloat()
                }
                val coverColors = intArrayOf(Color.rgb(215, 199, 179), Color.rgb(190, 198, 181), Color.rgb(205, 190, 190), Color.rgb(190, 198, 207), Color.rgb(218, 207, 179))
                val cover = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(coverColors[index % coverColors.size], 9)
                    setPadding(dp(6), dp(8), dp(6), dp(8))
                }
                cover.addView(text("BOOK", 9f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
                cover.addView(text("✦", 22f, Color.WHITE).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(5)) })
                item.addView(cover, LinearLayout.LayoutParams(dp(66), dp(92)))
                val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
                details.addView(text(book.title, 16f, ink, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                details.addView(text("TXT · EPUB 리더", 12f, muted).apply { setPadding(0, dp(7), 0, 0) })
                details.addView(text("읽기", 12f, accent, true).apply { setPadding(0, dp(12), 0, 0) })
                item.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                item.setOnClickListener { openBook(index) }
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(12)
                list.addView(item, lp)
            }
        }
    }

    private fun chooseBook() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream"))
        }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated in Android API but supported")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val name = queryName(uri)
        val content = if (name.lowercase().endsWith(".epub")) readEpub(uri) else readText(uri)
        books.removeAll { it.title == name }
        books.add(0, Book(name, content))
        openBook(0)
    }

    private fun queryName(uri: Uri): String = contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && idx >= 0) c.getString(idx) else "새 책"
    } ?: "새 책"

    private fun readText(uri: Uri): String = contentResolver.openInputStream(uri)?.use { input ->
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
    } ?: "파일을 읽을 수 없습니다."

    private fun readEpub(uri: Uri): String {
        val parts = mutableListOf<String>()
        contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val n = entry.name.lowercase()
                    if (!entry.isDirectory && (n.endsWith(".html") || n.endsWith(".xhtml") || n.endsWith(".htm")) && !n.contains("nav")) {
                        val body = zip.readBytes().toString(Charsets.UTF_8)
                        val plain = body.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                            .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>"), "\n\n")
                            .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&amp;", "&")
                            .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                        parts.add(plain)
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        parts.joinToString("\n\n").ifBlank { "EPUB 본문을 찾지 못했습니다." }
    }

    private fun openBook(index: Int) {
        if (index !in books.indices) return
        currentBook = index
        root.removeAllViews()
        root.setPadding(0, 0, 0, 0)

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(paper)
        }
        toolbar.addView(action("‹", false) { showShelf() })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0) }
        titleBox.addView(text(books[index].title, 14f, ink, true).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        titleBox.addView(text("차차의 서재", 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
        toolbar.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(action("Aa", false) { changeFont() })
        vertical(root, toolbar)

        val reader = WebView(this).apply {
            setBackgroundColor(paper)
            settings.javaScriptEnabled = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        web = reader
        root.addView(reader, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        render()

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(12))
            setBackgroundColor(paper)
        }
        bottom.addView(action("가 −", false) { fontSize = (fontSize - 1).coerceAtLeast(15); render() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(action("가 +", false) { fontSize = (fontSize + 1).coerceAtMost(30); render() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(action("줄 간격", false) { lineHeight = if (lineHeight < 2.0) 2.2 else 1.75; render() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(action("읽어주기", true) {
            val content = books.getOrNull(currentBook)?.text.orEmpty()
            if (content.isNotBlank()) tts.speak(content.take(3500), TextToSpeech.QUEUE_FLUSH, null, "reader")
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        vertical(root, bottom)
    }

    private fun changeFont() {
        val options = arrayOf("작게", "보통", "크게")
        val values = intArrayOf(16, 19, 23)
        val current = values.indices.minByOrNull { kotlin.math.abs(values[it] - fontSize) } ?: 1
        android.app.AlertDialog.Builder(this)
            .setTitle("글자 크기")
            .setSingleChoiceItems(options, current) { dialog, which ->
                fontSize = values[which]
                render()
                dialog.dismiss()
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    private fun render() {
        val book = books.getOrNull(currentBook) ?: return
        val paragraphs = book.text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
            .joinToString("") { "<p>${escape(it).replace("\n", "<br>")}</p>" }
        val page = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><style>
            *{box-sizing:border-box} html{background:#F9F7F1} body{margin:0;background:#F9F7F1;color:#393630;font-family:serif;font-size:${fontSize}px;line-height:${lineHeight};letter-spacing:.015em;padding:34px 25px 58px;word-break:keep-all;overflow-wrap:anywhere}
            .chapter{font-family:sans-serif;font-size:13px;color:#9A8E80;letter-spacing:.08em;margin:0 0 38px} p{margin:0 0 1.55em;text-align:justify} 
            </style></head><body><div class="chapter">${escape(book.title)}</div>$paragraphs</body></html>"""
        web?.loadDataWithBaseURL(null, page, "text/html", "UTF-8", null)
    }

    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    override fun onBackPressed() {
        if (web != null) showShelf() else super.onBackPressed()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.KOREAN
    }

    override fun onDestroy() {
        web?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
