package com.chacha.ebook

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.cancel
import java.util.zip.ZipFile
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private data class Chapter(val title: String, val text: String)
    private data class Book(
        val id: String, var title: String, var author: String, val text: String,
        val storedFileName: String, val coverFileName: String? = null,
        val chapters: List<Chapter> = emptyList(),
        val marks: MutableList<String> = mutableListOf(), val notes: MutableList<String> = mutableListOf()
    )

    private lateinit var root: LinearLayout
    private var aiEngine: com.ouor.supertonic.tts.SupertonicTts? = null
    private var aiPlayer: com.ouor.supertonic.audio.PcmPlayer? = null
    private val aiScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob())
    private var aiPlaybackJob: kotlinx.coroutines.Job? = null
    private var aiChunks: List<String> = emptyList()
    private var aiIndex = 0
    private var aiPaused = false
    private var selectedVoice = "M1"
    private var aiSpeed = 1.05f
    private var web: WebView? = null
    private val books = mutableListOf<Book>()
    private var current = -1
    private var font = 19
    private var line = 1.9
    private var pageMode = false
    private var auto = false
    private var darkMode = false
    private val handler = Handler(Looper.getMainLooper())
    private val autoTask = object : Runnable {
        override fun run() {
            if (auto) {
                web?.scrollBy(0, dp(2))
                handler.postDelayed(this, 45)
            }
        }
    }
    private val paper get() = if (darkMode) Color.rgb(35, 35, 37) else Color.rgb(249, 247, 241)
    private val ink get() = if (darkMode) Color.rgb(232, 229, 222) else Color.rgb(48, 45, 42)
    private val muted = Color.rgb(139, 132, 123)
    private val accent = Color.rgb(126, 105, 88)
    private val pick = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkMode = getSharedPreferences("reader", MODE_PRIVATE).getBoolean("dark", false)
        selectedVoice = getSharedPreferences("ai_tts", MODE_PRIVATE).getString("voice", "M1") ?: "M1"
        aiSpeed = getSharedPreferences("ai_tts", MODE_PRIVATE).getFloat("speed", 1.05f)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)
        loadBooks()
        showShelf()
    }

    private fun bookDir() = File(filesDir, "books").apply { if (!exists()) mkdirs() }
    private fun saveBooks() {
        val arr = JSONArray()
        books.forEach { b ->
            arr.put(JSONObject().put("id", b.id).put("title", b.title).put("author", b.author)
                .put("file", b.storedFileName).put("cover", b.coverFileName ?: "")
                .put("marks", JSONArray(b.marks)).put("notes", JSONArray(b.notes)))
        }
        getSharedPreferences("library", MODE_PRIVATE).edit().putString("books", arr.toString()).apply()
    }

    private fun loadBooks() {
        books.clear()
        val raw = getSharedPreferences("library", MODE_PRIVATE).getString("books", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("file")
                val f = File(bookDir(), name)
                if (!f.exists()) continue
                val parsed = if (name.lowercase().endsWith(".epub")) parseEpub(f) else ParsedBook(f.readText(Charsets.UTF_8), emptyList(), null)
                val marks = mutableListOf<String>(); val ma = o.optJSONArray("marks") ?: JSONArray()
                for (j in 0 until ma.length()) marks.add(ma.optString(j))
                val notes = mutableListOf<String>(); val na = o.optJSONArray("notes") ?: JSONArray()
                for (j in 0 until na.length()) notes.add(na.optString(j))
                val cover = o.optString("cover", "").ifBlank { parsed.coverFileName }
                books.add(Book(o.getString("id"), o.optString("title", "새 책"), o.optString("author", "작가명"), parsed.text, name, cover, parsed.chapters, marks, notes))
            }
        } catch (_: Exception) {
            Toast.makeText(this, "저장된 서재 정보를 읽지 못했습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun bg(color: Int, r: Int = 12) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(5), dp(12), dp(5), dp(12)); background = bg(Color.rgb(65, 61, 57), 10); setOnClickListener { action() }
    }
    private fun add(parent: LinearLayout, v: View, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
    }

    private fun showShelf() {
        stopAuto(); stopTts()
        web?.destroy(); web = null; root.removeAllViews(); root.setPadding(dp(18), dp(20), dp(18), dp(12)); root.setBackgroundColor(Color.rgb(246, 246, 246))
        val top = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val title = LinearLayout(this).apply { orientation = 1 }
        title.addView(label("차차의 서재", 25f, Color.rgb(48, 45, 42), true)); title.addView(label("나만의 전자책 공간", 12f, muted))
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(button("＋ 책 추가") { chooseBook() }); add(root, top)
        add(root, label("내 책  ${books.size}권", 13f, muted, true).apply { setPadding(0, dp(24), 0, dp(12)) })
        val sc = ScrollView(this); val list = LinearLayout(this).apply { orientation = 1 }; sc.addView(list); root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        if (books.isEmpty()) list.addView(label("아직 책이 없어요\nEPUB 또는 TXT 파일을 추가해 보세요.", 16f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(90), 0, 0) })
        books.forEachIndexed { i, b ->
            val row = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(Color.WHITE, 14) }
            val coverFile = b.coverFileName?.let { File(bookDir(), it) }
            val bitmap = if (coverFile?.exists() == true) BitmapFactory.decodeFile(coverFile.absolutePath) else null
            if (bitmap != null) row.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(62), dp(86)))
            else row.addView(label("BOOK\n✦", 12f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = bg(intArrayOf(0xff8d8176.toInt(), 0xff788575.toInt(), 0xff88777b.toInt())[i % 3], 8) }, LinearLayout.LayoutParams(dp(62), dp(86)))
            val info = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, 0, 0) }
            info.addView(label(b.title, 15f, Color.rgb(48, 45, 42), true)); info.addView(label(b.author, 12f, muted).apply { setPadding(0, dp(5), 0, 0) })
            info.addView(label("책갈피 ${b.marks.size}개", 11f, accent).apply { setPadding(0, dp(8), 0, 0) })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); row.setOnClickListener { openBook(i) }; row.setOnLongClickListener { bookOptions(i); true }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); list.addView(row, lp)
        }
    }

    private fun bookOptions(i: Int) {
        AlertDialog.Builder(this).setTitle(books[i].title).setItems(arrayOf("책 정보 수정", "서재에서 삭제")) { _, n -> if (n == 0) editBook(i) else deleteBook(i) }.setNegativeButton("취소", null).show()
    }
    private fun deleteBook(i: Int) {
        val b = books[i]
        AlertDialog.Builder(this).setTitle("책 삭제").setMessage("'${b.title}'을(를) 앱 서재에서 삭제할까요? 앱에 보관된 파일도 삭제됩니다. 휴대폰 원본 파일은 삭제되지 않습니다.")
            .setPositiveButton("삭제") { _, _ ->
                File(bookDir(), b.storedFileName).delete(); b.coverFileName?.let { File(bookDir(), it).delete() }
                books.removeAt(i); saveBooks(); showShelf()
            }.setNegativeButton("취소", null).show()
    }
    private fun editBook(i: Int) {
        val b = books[i]; val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(20), 0, dp(20), 0) }
        val t = EditText(this).apply { setText(b.title); hint = "책 제목" }; val a = EditText(this).apply { setText(b.author); hint = "작가명" }
        box.addView(t); box.addView(a)
        AlertDialog.Builder(this).setTitle("책 정보 수정").setView(box).setPositiveButton("저장") { _, _ -> b.title = t.text.toString(); b.author = a.text.toString(); saveBooks(); showShelf() }.setNegativeButton("취소", null).show()
    }
    private fun chooseBook() {
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream")) }
        startActivityForResult(it, pick)
    }
    @Deprecated("Deprecated") override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d); if (r != pick || c != RESULT_OK) return
        val u = d?.data ?: return
        val displayName = contentResolver.query(u, null, null, null, null)?.use { x ->
            val k = x.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (x.moveToFirst() && k >= 0) x.getString(k) else "새 책.txt"
        } ?: "새 책.txt"
        var copied: File? = null
        try {
            val epub = displayName.lowercase().endsWith(".epub"); val ext = if (epub) ".epub" else ".txt"
            val id = UUID.randomUUID().toString(); val stored = "$id$ext"; val dest = File(bookDir(), stored); copied = dest
            contentResolver.openInputStream(u)?.use { input -> FileOutputStream(dest).use { output -> input.copyTo(output) } } ?: throw Exception("파일을 열 수 없습니다.")
            val parsed = if (epub) parseEpub(dest, id) else ParsedBook(dest.readText(Charsets.UTF_8), emptyList(), null)
            val b = Book(id, displayName.substringBeforeLast('.'), "작가명", parsed.text, stored, parsed.coverFileName, parsed.chapters)
            books.add(0, b); saveBooks(); openBook(0)
            Toast.makeText(this, "책을 앱에 보관했어요. 원본을 삭제해도 읽을 수 있습니다.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            copied?.delete(); Toast.makeText(this, "책을 추가하지 못했습니다: ${e.message ?: "오류"}", Toast.LENGTH_LONG).show()
        }
    }

    private data class ParsedBook(val text: String, val chapters: List<Chapter>, val coverFileName: String?)
    private fun parseEpub(file: File, id: String = file.nameWithoutExtension): ParsedBook {
        ZipFile(file).use { zip ->
            fun readEntry(path: String): String = zip.getEntry(path)?.let { zip.getInputStream(it).bufferedReader(Charsets.UTF_8).use { r -> r.readText() } } ?: ""
            fun clean(html: String): String = html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>"), "\n\n")
                .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace(Regex("[ \\t]+"), " ").trim()
            val container = readEntry("META-INF/container.xml")
            val opfPath = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(container)?.groupValues?.get(1)
                ?: zip.entries().asSequence().firstOrNull { it.name.endsWith(".opf", true) }?.name
            if (opfPath == null) return ParsedBook("EPUB 목차 정보를 찾지 못했습니다.", emptyList(), null)
            val opf = readEntry(opfPath); val base = opfPath.substringBeforeLast('/', "")
            fun resolve(href: String) = if (base.isBlank()) href.substringBefore('#') else "$base/${href.substringBefore('#')}"
            val manifest = mutableMapOf<String, Pair<String, String>>()
            val itemRegex = Regex("<item\\b([^>]*)/?>", RegexOption.IGNORE_CASE)
            for (m in itemRegex.findAll(opf)) {
                val attrs = m.groupValues[1]
                val itemId = Regex("id=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val href = Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val props = Regex("properties=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: ""
                manifest[itemId] = Pair(resolve(href), props)
            }
            var coverPath: String? = manifest.values.firstOrNull { it.second.split(' ').contains("cover-image") }?.first
            if (coverPath == null) {
                val coverId = Regex("<meta\\b[^>]*name=['\"]cover['\"][^>]*content=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(opf)?.groupValues?.get(1)
                if (coverId != null) coverPath = manifest[coverId]?.first
            }
            var coverName: String? = null
            if (coverPath != null) {
                val entry = zip.getEntry(coverPath)
                if (entry != null) {
                    val suffix = coverPath.substringAfterLast('.', "jpg").take(5)
                    coverName = "${id}_cover.$suffix"
                    zip.getInputStream(entry).use { input -> FileOutputStream(File(bookDir(), coverName)).use { output -> input.copyTo(output) } }
                }
            }
            val titleByHref = mutableMapOf<String, String>()
            val navItem = manifest.values.firstOrNull { it.second.split(' ').contains("nav") }?.first
            if (navItem != null) {
                val navHtml = readEntry(navItem)
                val navBase = navItem.substringBeforeLast('/', "")
                val navRegex = Regex("<a\\b[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                for (m in navRegex.findAll(navHtml)) {
                    val href = m.groupValues[1].substringBefore('#')
                    val full = if (href.startsWith("/")) href.removePrefix("/") else if (navBase.isBlank()) href else "$navBase/$href"
                    titleByHref[full] = clean(m.groupValues[2]).replace(Regex("\\s+"), " ").take(100)
                }
            }
            if (titleByHref.isEmpty()) {
                val ncxPath = manifest.values.firstOrNull { it.first.endsWith(".ncx", true) }?.first
                if (ncxPath != null) {
                    val ncx = readEntry(ncxPath); val ncxBase = ncxPath.substringBeforeLast('/', "")
                    val navPoint = Regex("<navPoint\\b.*?</navPoint>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    for (m in navPoint.findAll(ncx)) {
                        val href = Regex("<content\\b[^>]*src=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(m.value)?.groupValues?.get(1)?.substringBefore('#') ?: continue
                        val label = Regex("<text>(.*?)</text>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(m.value)?.groupValues?.get(1)?.let { clean(it) } ?: continue
                        val full = if (href.startsWith("/")) href.removePrefix("/") else if (ncxBase.isBlank()) href else "$ncxBase/$href"
                        titleByHref[full] = label
                    }
                }
            }
            val spine = Regex("<itemref\\b[^>]*idref=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).findAll(opf).mapNotNull { manifest[it.groupValues[1]]?.first }.toList()
            val chapters = spine.mapNotNull { path ->
                val html = readEntry(path); if (html.isBlank()) null else {
                    val title = titleByHref[path] ?: Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)?.let { clean(it) }?.take(100) ?: "본문 ${spine.indexOf(path) + 1}"
                    val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    Chapter(title, clean(body))
                }
            }
            val finalChapters = chapters.ifEmpty {
                zip.entries().asSequence().filter { !it.isDirectory && it.name.endsWith(".xhtml", true) }.mapNotNull { e ->
                    val html = readEntry(e.name); val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    clean(body).takeIf { it.isNotBlank() }?.let { Chapter(e.name.substringAfterLast('/').substringBeforeLast('.'), it) }
                }.toList()
            }
            val text = finalChapters.joinToString("\n\n") { it.text }.ifBlank { "EPUB 본문을 찾지 못했습니다." }
            return ParsedBook(text, finalChapters, coverName)
        }
    }

    private fun openBook(i: Int) {
        if (i !in books.indices) return
        stopAuto(); stopTts(); current = i; root.removeAllViews(); root.setPadding(0, 0, 0, 0); root.setBackgroundColor(paper)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(paper) }
        top.addView(button("‹ 뒤로") { showShelf() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("검색") { search() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("책갈피＋") { bookmark() }, LinearLayout.LayoutParams(0, -2, 1f)); add(root, top)
        val w = WebView(this).apply { setBackgroundColor(paper); settings.javaScriptEnabled = true; isVerticalScrollBarEnabled = false }
        web = w; root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        val bar = LinearLayout(this).apply { orientation = 0; setPadding(dp(4), dp(7), dp(4), dp(7)); setBackgroundColor(Color.rgb(35, 35, 37)) }
        val actions = listOf("목차", "TTS", "자동\n스크롤", "독서노트", "보기\n설정", "뷰어\n설정")
        actions.forEachIndexed { n, s -> bar.addView(button(s) { when (n) { 0 -> toc(); 1 -> ttsControls(); 2 -> toggleAuto(); 3 -> notes(); 4 -> viewSettings(); 5 -> readerSettings() } }, LinearLayout.LayoutParams(0, -2, 1f)) }
        add(root, bar)
    }

    private fun render() {
        val b = books.getOrNull(current) ?: return
        val paras = b.text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }.mapIndexed { idx, it -> "<p id=\"para$idx\">${esc(it).replace("\n", "<br>")}</p>" }.joinToString("")
        val mode = if (pageMode) "column-width:88vw;column-gap:10vw;" else "column-width:auto;"
        val bg = if (darkMode) "#232325" else "#F9F7F1"; val fg = if (darkMode) "#E8E5DE" else "#393630"
        val html = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>*{box-sizing:border-box}html,body{margin:0;background:$bg;color:$fg}body{font-family:serif;font-size:${font}px;line-height:$line;padding:30px 24px 55px;word-break:keep-all;overflow-wrap:anywhere;$mode}p{margin:0 0 1.6em;text-align:justify}</style></head><body>$paras</body></html>"""
        web?.setBackgroundColor(paper); web?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun bookmark() { val b = books.getOrNull(current) ?: return; b.marks.add("책갈피 ${b.marks.size + 1} · ${b.title}"); saveBooks(); Toast.makeText(this, "책갈피에 추가했어요", Toast.LENGTH_SHORT).show() }
    private fun search() { val e = EditText(this).apply { hint = "검색할 내용" }; AlertDialog.Builder(this).setTitle("책 속 내용 검색").setView(e).setPositiveButton("검색") { _, _ -> web?.findAllAsync(e.text.toString()) }.setNegativeButton("취소", null).show() }

    private fun toc() {
        val b = books.getOrNull(current) ?: return
        if (b.chapters.isNotEmpty()) {
            val entries = b.chapters.map { it.title }.toTypedArray()
            AlertDialog.Builder(this).setTitle("EPUB 원본 목차").setItems(entries) { _, which ->
                val target = b.chapters.take(which).sumOf { it.text.split(Regex("\\n\\s*\\n")).count { p -> p.isNotBlank() } }
                web?.evaluateJavascript("document.getElementById('para$target')?.scrollIntoView();", null)
            }.setNegativeButton("닫기", null).show()
        } else {
            AlertDialog.Builder(this).setTitle("목차").setMessage("이 TXT 파일에는 원본 목차가 없습니다.").setPositiveButton("확인", null).show()
        }
    }
    private fun notes() {
        val b = books.getOrNull(current) ?: return; val all = (b.marks + b.notes).toTypedArray()
        AlertDialog.Builder(this).setTitle("독서노트 · 전체 ${all.size}개").setItems(all.ifEmpty { arrayOf("저장된 내용이 없습니다.") }) { _, _ -> }
            .setPositiveButton("메모 추가") { _, _ -> val e = EditText(this).apply { hint = "메모를 입력하세요" }; AlertDialog.Builder(this).setTitle("독서 메모").setView(e).setPositiveButton("저장") { _, _ -> b.notes.add(e.text.toString()); saveBooks() }.setNegativeButton("취소", null).show() }
            .setNegativeButton("닫기", null).show()
    }

    private fun ttsControls() {
        val options = arrayOf("처음부터 AI 음성으로 읽기", "일시정지", "이어 읽기", "남성 목소리 선택 (현재 $selectedVoice)", "읽기 속도 설정", "읽기 중지")
        AlertDialog.Builder(this).setTitle("AI 책 읽어주기 · Supertonic")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startAiTts(true)
                    1 -> pauseAiTts()
                    2 -> resumeAiTts()
                    3 -> chooseAiVoice()
                    4 -> chooseAiSpeed()
                    5 -> stopTts()
                }
            }.setNegativeButton("닫기", null).show()
    }

    private fun chooseAiVoice() {
        val voices = arrayOf("M1", "M2", "M3", "M4", "M5")
        AlertDialog.Builder(this).setTitle("남성 AI 목소리 선택")
            .setSingleChoiceItems(voices, voices.indexOf(selectedVoice).coerceAtLeast(0)) { dialog, which ->
                selectedVoice = voices[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putString("voice", selectedVoice).apply()
                dialog.dismiss()
                Toast.makeText(this, "$selectedVoice 목소리로 설정했어요.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("취소", null).show()
    }

    private fun chooseAiSpeed() {
        val speeds = floatArrayOf(0.8f, 0.9f, 1.0f, 1.05f, 1.2f, 1.35f)
        val labels = arrayOf("0.8배", "0.9배", "1.0배", "1.05배", "1.2배", "1.35배")
        val selected = speeds.indices.minByOrNull { kotlin.math.abs(speeds[it] - aiSpeed) } ?: 3
        AlertDialog.Builder(this).setTitle("읽기 속도")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                aiSpeed = speeds[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putFloat("speed", aiSpeed).apply()
                dialog.dismiss()
            }.setNegativeButton("취소", null).show()
    }

    private fun startAiTts(restart: Boolean) {
        val text = books.getOrNull(current)?.text.orEmpty()
        if (text.isBlank()) return
        if (restart || aiChunks.isEmpty()) {
            aiChunks = text.split(Regex("(?<=[.!?。！？])\\s+|\\n+"))
                .flatMap { part -> if (part.length > 420) part.chunked(420) else listOf(part) }
                .filter { it.isNotBlank() }
            aiIndex = 0
        }
        aiPaused = false
        ensureAiEngine {
            if (aiIndex < aiChunks.size) playAiChunks()
        }
    }

    private fun resumeAiTts() {
        if (aiChunks.isEmpty()) { startAiTts(true); return }
        aiPaused = false
        ensureAiEngine { if (aiIndex < aiChunks.size) playAiChunks() }
    }

    private fun pauseAiTts() {
        aiPaused = true
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        Toast.makeText(this, "일시정지했어요.", Toast.LENGTH_SHORT).show()
    }

    private fun playAiChunks() {
        val engine = aiEngine ?: return
        aiPlaybackJob?.cancel()
        aiPlaybackJob = aiScope.launch {
            try {
                while (!aiPaused && aiIndex < aiChunks.size) {
                    val chunk = aiChunks[aiIndex]
                    val pcm = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val style = com.ouor.supertonic.tts.VoiceStyle.load(
                            com.ouor.supertonic.data.ModelAssets.voiceStyleFile(this@MainActivity, selectedVoice)
                        )
                        engine.synthesize(chunk, "ko", style, totalStep = 8, speed = aiSpeed).wav
                    }
                    aiPlayer?.play(pcm, null)
                    aiIndex++
                }
                if (aiIndex >= aiChunks.size) {
                    aiChunks = emptyList(); aiIndex = 0
                    Toast.makeText(this@MainActivity, "읽기가 끝났어요.", Toast.LENGTH_SHORT).show()
                }
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Pause/stop requested by the user.
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "AI 음성 재생 오류: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun ensureAiEngine(onReady: () -> Unit) {
        if (aiEngine != null) { onReady(); return }
        if (!com.ouor.supertonic.data.ModelAssets.isReady(this)) {
            AlertDialog.Builder(this).setTitle("AI 음성 모델 다운로드")
                .setMessage("처음 한 번만 약 400MB의 음성 모델을 다운로드합니다. 이후에는 인터넷 없이 사용할 수 있어요. Wi-Fi 연결을 권장합니다.")
                .setPositiveButton("다운로드") { _, _ -> downloadAiModel(onReady) }
                .setNegativeButton("취소", null).show()
        } else loadAiEngine(onReady)
    }

    private fun downloadAiModel(onReady: () -> Unit) {
        val progress = android.app.ProgressDialog(this).apply {
            setTitle("AI 음성 모델 다운로드")
            setMessage("다운로드 준비 중...")
            setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
            max = 100; setCancelable(false); show()
        }
        aiScope.launch {
            var completed = false
            try {
                com.ouor.supertonic.data.ModelDownloader(this@MainActivity).download().collect { state ->
                    when (state) {
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Running -> {
                            val percent = if (state.totalBytes > 0) ((state.downloadedBytes * 100) / state.totalBytes).toInt() else 0
                            progress.progress = percent
                            progress.setMessage("파일 ${state.fileIndex + 1}/${state.fileCount} 다운로드 중... $percent%")
                        }
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Done -> completed = true
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Failed -> throw IllegalStateException(state.message)
                    }
                }
                progress.dismiss()
                if (!completed) throw IllegalStateException("다운로드가 완료되지 않았습니다.")
                loadAiEngine(onReady)
            } catch (e: Exception) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, "모델 다운로드 실패: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadAiEngine(onReady: () -> Unit) {
        Toast.makeText(this, "AI 음성 엔진을 준비하고 있어요.", Toast.LENGTH_SHORT).show()
        aiScope.launch {
            try {
                val engine = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.ouor.supertonic.tts.SupertonicTts.load(com.ouor.supertonic.data.ModelAssets.onnxDir(this@MainActivity))
                }
                aiEngine?.close()
                aiEngine = engine
                aiPlayer = com.ouor.supertonic.audio.PcmPlayer(engine.sampleRate)
                onReady()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "AI 음성 엔진 오류: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stopTts() {
        aiPaused = false
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        aiChunks = emptyList(); aiIndex = 0
    }

    private fun stopAuto() { auto = false; handler.removeCallbacks(autoTask) }
    private fun toggleAuto() {
        auto = !auto
        if (auto) handler.post(autoTask) else handler.removeCallbacks(autoTask)
        Toast.makeText(this, if (auto) "자동 스크롤 켜짐" else "자동 스크롤 꺼짐", Toast.LENGTH_SHORT).show()
    }
    private fun viewSettings() {
        val opts = arrayOf("페이지 넘김", "세로 스크롤", if (darkMode) "아이보리 모드로 전환" else "다크모드로 전환")
        AlertDialog.Builder(this).setTitle("읽기 방식 및 화면")
            .setSingleChoiceItems(opts, if (pageMode) 0 else 1) { d, n ->
                when (n) { 0 -> pageMode = true; 1 -> pageMode = false; 2 -> { darkMode = !darkMode; getSharedPreferences("reader", MODE_PRIVATE).edit().putBoolean("dark", darkMode).apply() } }
                render(); d.dismiss()
            }.show()
    }
    private fun readerSettings() {
        val opts = arrayOf("글자 크기 줄이기", "글자 크기 키우기", "줄 간격 변경")
        AlertDialog.Builder(this).setTitle("보기 설정").setItems(opts) { _, n ->
            when (n) { 0 -> font = (font - 1).coerceAtLeast(14); 1 -> font = (font + 1).coerceAtMost(32); 2 -> line = if (line < 2.0) 2.2 else 1.7 }
            render()
        }.show()
    }

    override fun onBackPressed() { if (web != null) showShelf() else super.onBackPressed() }
    override fun onDestroy() {
        stopAuto(); stopTts(); aiScope.cancel(); aiEngine?.close(); aiPlayer?.stop(); web?.destroy(); super.onDestroy()
    }
