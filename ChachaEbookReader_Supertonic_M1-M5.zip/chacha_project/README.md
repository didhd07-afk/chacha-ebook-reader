# 차차의 서재

Android EPUB/TXT 리더와 오프라인 한국어 남성 AI TTS(Supertonic 3)를 통합한 프로젝트입니다.

## AI TTS
- 남성 음성 M1~M5 선택
- 읽기 시작, 일시정지, 이어 읽기, 중지
- 읽기 속도 설정
- 첫 실행 시 Hugging Face에서 약 400MB 모델을 한 번 다운로드하며, 이후 오프라인 사용 가능
- 유료 API 및 광고 없음

## 요구 사항
- Android 9(API 28) 이상, arm64-v8a 권장
- 최초 모델 다운로드 시 인터넷 연결 및 약 400MB 저장 공간 필요

## 빌드
GitHub Actions에서 기존 workflow로 assembleDebug를 실행할 수 있습니다. Gradle Wrapper는 포함하지 않습니다.

## 참고
Supertonic Android TTS 엔진 소스는 제공된 ouor/supertonic-android 프로젝트에서 가져왔으며, 모델은 별도 다운로드됩니다. 기존 전자책 리더 화면과 기능은 유지했습니다.
