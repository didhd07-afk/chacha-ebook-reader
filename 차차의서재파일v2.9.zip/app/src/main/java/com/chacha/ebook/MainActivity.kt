package com.chacha.ebook

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.JavascriptInterface
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.cancel
import java.util.zip.ZipFile
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private data class Chapter(val title: String, val text: String)
    private data class Book(
        val id: String, var title: String, var author: String, val text: String,
        val storedFileName: String, val coverFileName: String? = null,
        val chapters: List<Chapter> = emptyList(),
        val marks: MutableList<String> = mutableListOf(), val notes: MutableList<String> = mutableListOf(),
        var genre: String = "기타"
    )

    private lateinit var root: LinearLayout
    private var aiEngine: com.ouor.supertonic.tts.SupertonicTts? = null
    private var aiPlayer: com.ouor.supertonic.audio.PcmPlayer? = null
    private val aiScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob())
    private var aiPlaybackJob: kotlinx.coroutines.Job? = null
    private var aiChunks: List<String> = emptyList()
    private var aiParagraphEnds: Set<Int> = emptySet()
    private var aiPreparing = false
    private val aiEngineReadyCallbacks = mutableListOf<() -> Unit>()
    private var aiIndex = 0
    private var aiPaused = false
    private var selectedVoice = "M1"
    private var aiSpeed = 1.05f
    private var web: WebView? = null
    private var ttsPlayerBar: LinearLayout? = null
    private var pageSeekBar: SeekBar? = null
    private var pageCountLabel: TextView? = null
    private var readerCurrentPage = 0
    private var readerTotalPages = 1
    private val readerPageHistory = java.util.ArrayDeque<Int>()
    private var sortMode = "recent"
    private var selectedGenre = "전체"
    private var shelfSearch = ""
    private var shelfTab = "내서재"
    private val defaultGenres = listOf("로맨스", "판타지", "무협", "BL", "역사/시대물", "기타")
    private val customGenres = linkedSetOf<String>()
    private val shelfBg get() = if (darkMode) Color.rgb(17, 18, 21) else Color.rgb(246, 244, 239)
    private val cardBg get() = if (darkMode) Color.rgb(38, 39, 44) else Color.WHITE
    private val purple = Color.rgb(166, 133, 255)
    private val books = mutableListOf<Book>()
    private var current = -1
    private var font = 19
    private var line = 1.9
    private var pageMode = false
    private var pendingBookmark = false
    private var auto = false
    private var darkMode = false
    private val handler = Handler(Looper.getMainLooper())
    private val autoTask = object : Runnable {
        override fun run() {
            if (auto) {
                web?.scrollBy(0, dp(2))
                handler.postDelayed(this, 45)
            }
        }
    }
    private val paper get() = if (darkMode) Color.rgb(35, 35, 37) else Color.rgb(249, 247, 241)
    private val ink get() = if (darkMode) Color.rgb(232, 229, 222) else Color.rgb(48, 45, 42)
    private val muted = Color.rgb(139, 132, 123)
    private val accent = Color.rgb(126, 105, 88)
    private val pick = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkMode = getSharedPreferences("reader", MODE_PRIVATE).getBoolean("dark", false)
        selectedVoice = getSharedPreferences("ai_tts", MODE_PRIVATE).getString("voice", "M1") ?: "M1"
        sortMode = getSharedPreferences("library", MODE_PRIVATE).getString("sort", "recent") ?: "recent"
        customGenres.addAll(getSharedPreferences("library", MODE_PRIVATE).getStringSet("custom_genres", emptySet()) ?: emptySet())
        aiSpeed = getSharedPreferences("ai_tts", MODE_PRIVATE).getFloat("speed", 1.05f)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)
        loadBooks()
        showShelf()
    }

    private fun bookDir() = File(filesDir, "books").apply { if (!exists()) mkdirs() }
    private fun saveBooks() {
        val arr = JSONArray()
        books.forEach { b ->
            arr.put(JSONObject().put("id", b.id).put("title", b.title).put("author", b.author)
                .put("file", b.storedFileName).put("cover", b.coverFileName ?: "").put("genre", b.genre)
                .put("marks", JSONArray(b.marks)).put("notes", JSONArray(b.notes)))
        }
        getSharedPreferences("library", MODE_PRIVATE).edit().putString("books", arr.toString()).apply()
    }

    private fun loadBooks() {
        books.clear()
        val raw = getSharedPreferences("library", MODE_PRIVATE).getString("books", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("file")
                val f = File(bookDir(), name)
                if (!f.exists()) continue
                val parsed = if (name.lowercase().endsWith(".epub")) parseEpub(f) else ParsedBook(f.readText(Charsets.UTF_8), emptyList(), null)
                val marks = mutableListOf<String>(); val ma = o.optJSONArray("marks") ?: JSONArray()
                for (j in 0 until ma.length()) marks.add(ma.optString(j))
                val notes = mutableListOf<String>(); val na = o.optJSONArray("notes") ?: JSONArray()
                for (j in 0 until na.length()) notes.add(na.optString(j))
                val cover = o.optString("cover", "").ifBlank { parsed.coverFileName }
                books.add(Book(o.getString("id"), o.optString("title", "새 책"), o.optString("author", "작가명"), parsed.text, name, cover, parsed.chapters, marks, notes, o.optString("genre", "기타")))
            }
        } catch (_: Exception) {
            Toast.makeText(this, "저장된 서재 정보를 읽지 못했습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun bg(color: Int, r: Int = 12) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(5), dp(12), dp(5), dp(12)); background = bg(Color.rgb(65, 61, 57), 10); setOnClickListener { action() }
    }
    private fun add(parent: LinearLayout, v: View, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
    }

    private fun showShelf() {
        stopAuto(); stopTts()
        web?.destroy(); web = null; root.removeAllViews()
        root.setPadding(dp(16), dp(14), dp(16), 0)
        val bgShelf = Color.rgb(17, 18, 20)
        val panel = Color.rgb(31, 32, 35)
        val secondary = Color.rgb(145, 145, 151)
        val white = Color.rgb(235, 235, 239)
        root.setBackgroundColor(bgShelf)

        val header = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("차차의 책장", 19f, white, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(label("⌕", 25f, white).apply { gravity = Gravity.CENTER; setOnClickListener { searchShelf() } }, LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(label("⋮", 24f, white).apply { gravity = Gravity.CENTER; setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setItems(arrayOf("책 추가", "장르 추가", "정렬 방식", if (darkMode) "밝은 화면" else "어두운 화면")) { _, which ->
                when (which) { 0 -> chooseBook(); 1 -> addGenre(); 2 -> chooseShelfSort(); 3 -> { darkMode = !darkMode; getSharedPreferences("reader", MODE_PRIVATE).edit().putBoolean("dark", darkMode).apply(); showShelf() } }
            }.show()
        } }, LinearLayout.LayoutParams(dp(34), dp(42)))
        add(root, header)

        val tabs = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        listOf("전체", "내서재", "내책장").forEach { tab ->
            val active = shelfTab == tab
            val t = label(tab, 13f, if (active) white else secondary, active).apply {
                gravity = Gravity.CENTER; setPadding(dp(18), dp(10), dp(18), dp(10))
                setOnClickListener { shelfTab = tab; if (tab == "내책장") selectedGenre = "전체"; showShelf() }
            }
            tabs.addView(t)
        }
        add(root, tabs)
        val line = View(this).apply { setBackgroundColor(Color.rgb(57, 58, 62)) }
        add(root, line, dp(1))

        if (shelfTab == "내책장") {
            if (selectedGenre == "전체") {
                renderGenreShelf(white, secondary, panel)
            } else {
                renderGenreBookList(white, secondary, panel)
            }
            addShelfBottom(white, secondary)
            return
        }

        val shown = books.withIndex().filter { indexed ->
            matchesShelfSearch(indexed.value, shelfSearch)
        }
        val controls = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        controls.addView(label("${shown.size}권", 12f, secondary), LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(label("편집", 12f, white).apply { setPadding(dp(12), dp(7), dp(12), dp(7)); background = bg(panel, 6); setOnClickListener { editShelfItems() } })
        val sort = label("☷  정렬 · 필터", 12f, white).apply { setPadding(dp(12), dp(7), dp(12), dp(7)); background = bg(panel, 6); setOnClickListener { chooseShelfSort() } }
        val sortLp = LinearLayout.LayoutParams(-2, -2); sortLp.leftMargin = dp(8); controls.addView(sort, sortLp)
        add(root, controls)

        val sc = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = 1 }
        sc.addView(list)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        val ordered = when (sortMode) {
            "title" -> shown.sortedBy { it.value.title.lowercase() }
            "author" -> shown.sortedBy { it.value.author.lowercase() }
            else -> shown.sortedByDescending { it.index }
        }
        if (ordered.isEmpty()) list.addView(label(if (shelfSearch.isBlank()) "서재에 책이 없습니다." else "검색 결과가 없습니다.", 14f, secondary).apply { gravity = Gravity.CENTER; setPadding(0, dp(70), 0, 0) })
        ordered.forEach { indexed ->
            val i = indexed.index; val b = indexed.value
            val row = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(9), dp(4), dp(9)) }
            val coverFile = b.coverFileName?.let { File(bookDir(), it) }
            val bitmap = if (coverFile?.exists() == true) BitmapFactory.decodeFile(coverFile.absolutePath) else null
            if (bitmap != null) row.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(58), dp(82)))
            else row.addView(label("BOOK", 10f, white, true).apply { gravity = Gravity.CENTER; background = bg(Color.rgb(76, 68, 78), 5) }, LinearLayout.LayoutParams(dp(58), dp(82)))
            val info = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, dp(4), 0) }
            info.addView(label(b.title, 14f, white, true).apply { maxLines = 2 })
            val size = File(bookDir(), b.storedFileName).let { if (it.exists()) String.format(java.util.Locale.KOREA, "%.1fMB", it.length() / 1048576.0) else "" }
            info.addView(label(size, 10f, secondary).apply { setPadding(0, dp(5), 0, 0) })
            info.addView(label(b.author, 10f, secondary).apply { setPadding(0, dp(5), 0, 0) })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val mark = label("♧${b.marks.size}", 12f, secondary).apply { gravity = Gravity.CENTER; setPadding(dp(5), 0, dp(5), 0); setOnClickListener { current = i; showBookmarkList() } }
            row.addView(mark, LinearLayout.LayoutParams(dp(36), dp(48)))
            row.addView(label("⋮", 20f, secondary).apply { gravity = Gravity.CENTER; setOnClickListener { bookOptions(i) } }, LinearLayout.LayoutParams(dp(26), dp(48)))
            row.setOnClickListener { openBook(i) }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(3); list.addView(row, lp)
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(42, 43, 46)) }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        addShelfBottom(white, secondary)
    }

    private fun normalizeShelfText(value: String): String =
        java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKC)
            .lowercase(java.util.Locale.ROOT)
            .filter { it.isLetterOrDigit() }

    private fun matchesShelfSearch(book: Book, query: String): Boolean {
        val normalizedQuery = normalizeShelfText(query)
        if (normalizedQuery.isBlank()) return true

        val searchableFields = listOf(book.title, book.author, book.storedFileName)
            .map(::normalizeShelfText)
            .filter { it.isNotBlank() }

        // First try the full query (ignoring spaces and punctuation), then allow
        // separated search terms to match within the title/author/file name.
        return searchableFields.any { it.contains(normalizedQuery) } ||
            query.split(Regex("\\s+"))
                .map(::normalizeShelfText)
                .filter { it.isNotBlank() }
                .all { term -> searchableFields.any { it.contains(term) } }
    }

    private fun renderGenreShelf(white: Int, secondary: Int, panel: Int) {
        val sc = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(16)) }
        sc.addView(content)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        val genres = (defaultGenres + customGenres + books.map { it.genre }).distinct()
        val symbols = mapOf("로맨스" to "▣", "판타지" to "♛", "무협" to "⚔", "BL" to "♟", "역사/시대물" to "♜", "기타" to "★")
        genres.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = 0 }
            pair.forEach { genre ->
                val count = books.count { it.genre == genre }
                val card = LinearLayout(this).apply {
                    orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); background = bg(Color.rgb(37, 38, 43), 13)
                }
                val info = LinearLayout(this).apply { orientation = 1 }
                info.addView(label(symbols[genre] ?: "▣", 20f, purple, true))
                info.addView(label(genre, 13f, white, true).apply { setPadding(0, dp(5), 0, 0) })
                info.addView(label("${count}권", 10f, secondary).apply { setPadding(0, dp(3), 0, 0) })
                card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val covers = books.filter { it.genre == genre }.takeLast(2)
                covers.forEach { book ->
                    val file = book.coverFileName?.let { File(bookDir(), it) }
                    val bitmap = if (file?.exists() == true) BitmapFactory.decodeFile(file.absolutePath) else null
                    if (bitmap != null) card.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(32), dp(54)).apply { leftMargin = dp(3) })
                }
                card.setOnClickListener { selectedGenre = genre; showShelf() }
                val lp = LinearLayout.LayoutParams(0, dp(104), 1f).apply { if (row.childCount > 0) leftMargin = dp(8) }
                row.addView(card, lp)
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(8) })
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
            content.addView(row, lp)
        }
    }

    private fun renderGenreBookList(white: Int, secondary: Int, panel: Int) {
        val header = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(10)) }
        header.addView(label("‹  장르 목록", 13f, purple, true).apply { setOnClickListener { selectedGenre = "전체"; showShelf() } }, LinearLayout.LayoutParams(0, -2, 1f))
        val matches = books.withIndex().filter { it.value.genre == selectedGenre && matchesShelfSearch(it.value, shelfSearch) }
        header.addView(label("${matches.size}권", 11f, secondary))
        add(root, header)
        val sc = ScrollView(this); val list = LinearLayout(this).apply { orientation = 1 }; sc.addView(list)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        matches.forEach { indexed ->
            val i = indexed.index; val b = indexed.value
            val row = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(9), dp(4), dp(9)) }
            val coverFile = b.coverFileName?.let { File(bookDir(), it) }
            val bitmap = if (coverFile?.exists() == true) BitmapFactory.decodeFile(coverFile.absolutePath) else null
            if (bitmap != null) row.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(58), dp(82)))
            else row.addView(label("BOOK", 10f, white, true).apply { gravity = Gravity.CENTER; background = bg(Color.rgb(76, 68, 78), 5) }, LinearLayout.LayoutParams(dp(58), dp(82)))
            val info = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, dp(4), 0) }
            info.addView(label(b.title, 14f, white, true).apply { maxLines = 2 })
            info.addView(label(b.author, 10f, secondary).apply { setPadding(0, dp(5), 0, 0) })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("♧${b.marks.size}", 12f, secondary).apply { gravity = Gravity.CENTER; setOnClickListener { current = i; showBookmarkList() } }, LinearLayout.LayoutParams(dp(36), dp(48)))
            row.addView(label("⋮", 20f, secondary).apply { gravity = Gravity.CENTER; setOnClickListener { bookOptions(i) } }, LinearLayout.LayoutParams(dp(26), dp(48)))
            row.setOnClickListener { openBook(i) }
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(42, 43, 46)) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        if (matches.isEmpty()) list.addView(label("이 장르에 등록된 책이 없습니다.", 13f, secondary).apply { gravity = Gravity.CENTER; setPadding(0, dp(50), 0, 0) })
    }

    private fun addShelfBottom(white: Int, secondary: Int) {
        val bottom = LinearLayout(this).apply { orientation = 1; setBackgroundColor(Color.rgb(29, 30, 33)) }
        if (aiChunks.isNotEmpty()) {
            val mini = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
            val b = books.getOrNull(current)
            val cover = b?.coverFileName?.let { File(bookDir(), it) }
            val bmp = if (cover?.exists() == true) BitmapFactory.decodeFile(cover.absolutePath) else null
            if (bmp != null) mini.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(34), dp(42)))
            mini.addView(label(b?.title ?: "AI 듣기", 11f, white, true).apply { setPadding(dp(10), 0, 0, 0); maxLines = 1 }, LinearLayout.LayoutParams(0, -2, 1f))
            mini.addView(label("☷", 20f, white).apply { gravity = Gravity.CENTER; setOnClickListener { if (current >= 0) openBook(current) } }, LinearLayout.LayoutParams(dp(40), dp(42)))
            bottom.addView(mini)
        }
        val nav = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(7), dp(16), dp(7)) }
        nav.addView(label("▮▮▮  내 서재", 12f, purple, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        nav.addView(label("⌕\n검색", 11f, secondary).apply { gravity = Gravity.CENTER; setOnClickListener { searchShelf() } }, LinearLayout.LayoutParams(dp(60), dp(44)))
        bottom.addView(nav)
        add(root, bottom)
    }

    private fun searchShelf() {
        val input = EditText(this).apply { hint = "책 제목 또는 작가 검색"; setSingleLine(true); setText(shelfSearch) }
        AlertDialog.Builder(this).setTitle("내 서재 검색").setView(input)
            .setPositiveButton("검색") { _, _ -> shelfSearch = input.text.toString().trim(); showShelf() }
            .setNeutralButton("초기화") { _, _ -> shelfSearch = ""; showShelf() }
            .setNegativeButton("취소", null).show()
    }

    private fun editShelfItems() {
        val names = books.map { it.title }.toTypedArray()
        if (names.isEmpty()) return
        AlertDialog.Builder(this).setTitle("책 선택 · 길게 눌러 관리")
            .setItems(names) { _, which -> bookOptions(which) }.setNegativeButton("닫기", null).show()
    }

    private fun addGenre() {
        val input = EditText(this).apply { hint = "새 장르 이름" }
        AlertDialog.Builder(this).setTitle("장르 추가").setView(input)
            .setPositiveButton("추가") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) { customGenres.add(name); getSharedPreferences("library", MODE_PRIVATE).edit().putStringSet("custom_genres", customGenres.toSet()).apply(); selectedGenre = name; showShelf() }
            }.setNegativeButton("취소", null).show()
    }

    private fun chooseBookGenre(index: Int) {
        val choices = (defaultGenres + customGenres + books.map { it.genre }).distinct().toMutableList()
        choices.add("＋ 새 장르")
        AlertDialog.Builder(this).setTitle("책 장르 선택").setItems(choices.toTypedArray()) { _, which ->
            if (which == choices.lastIndex) {
                val input = EditText(this).apply { hint = "장르 이름" }
                AlertDialog.Builder(this).setTitle("새 장르").setView(input).setPositiveButton("저장") { _, _ ->
                    input.text.toString().trim().takeIf { it.isNotEmpty() }?.let { customGenres.add(it); getSharedPreferences("library", MODE_PRIVATE).edit().putStringSet("custom_genres", customGenres.toSet()).apply(); books[index].genre = it; saveBooks(); selectedGenre = it; showShelf() }
                }.setNegativeButton("취소", null).show()
            } else { books[index].genre = choices[which]; saveBooks(); selectedGenre = choices[which]; showShelf() }
        }.setNegativeButton("취소", null).show()
    }

    private fun chooseShelfSort() {
        val opts = arrayOf("최근 추가순", "제목 가나다순", "작가 가나다순")
        val selected = when (sortMode) { "title" -> 1; "author" -> 2; else -> 0 }
        AlertDialog.Builder(this).setTitle("서재 정렬").setSingleChoiceItems(opts, selected) { d, n ->
            sortMode = arrayOf("recent", "title", "author")[n]
            getSharedPreferences("library", MODE_PRIVATE).edit().putString("sort", sortMode).apply()
            d.dismiss(); showShelf()
        }.setNegativeButton("취소", null).show()
    }

    private fun bookOptions(i: Int) {
        AlertDialog.Builder(this).setTitle(books[i].title).setItems(arrayOf("책 정보 수정", "장르 변경", "서재에서 삭제")) { _, n -> when (n) { 0 -> editBook(i); 1 -> chooseBookGenre(i); else -> deleteBook(i) } }.setNegativeButton("취소", null).show()
    }
    private fun deleteBook(i: Int) {
        val b = books[i]
        AlertDialog.Builder(this).setTitle("책 삭제").setMessage("'${b.title}'을(를) 앱 서재에서 삭제할까요? 앱에 보관된 파일도 삭제됩니다. 휴대폰 원본 파일은 삭제되지 않습니다.")
            .setPositiveButton("삭제") { _, _ ->
                File(bookDir(), b.storedFileName).delete(); b.coverFileName?.let { File(bookDir(), it).delete() }
                books.removeAt(i); saveBooks(); showShelf()
            }.setNegativeButton("취소", null).show()
    }
    private fun editBook(i: Int) {
        val b = books[i]; val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(20), 0, dp(20), 0) }
        val t = EditText(this).apply { setText(b.title); hint = "책 제목" }; val a = EditText(this).apply { setText(b.author); hint = "작가명" }
        box.addView(t); box.addView(a)
        AlertDialog.Builder(this).setTitle("책 정보 수정").setView(box).setPositiveButton("저장") { _, _ -> b.title = t.text.toString(); b.author = a.text.toString(); saveBooks(); showShelf() }.setNegativeButton("취소", null).show()
    }
    private fun chooseBook() {
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream")) }
        startActivityForResult(it, pick)
    }
    @Deprecated("Deprecated") override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d); if (r != pick || c != RESULT_OK) return
        val u = d?.data ?: return
        val displayName = contentResolver.query(u, null, null, null, null)?.use { x ->
            val k = x.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (x.moveToFirst() && k >= 0) x.getString(k) else "새 책.txt"
        } ?: "새 책.txt"
        var copied: File? = null
        try {
            val epub = displayName.lowercase().endsWith(".epub"); val ext = if (epub) ".epub" else ".txt"
            val id = UUID.randomUUID().toString(); val stored = "$id$ext"; val dest = File(bookDir(), stored); copied = dest
            contentResolver.openInputStream(u)?.use { input -> FileOutputStream(dest).use { output -> input.copyTo(output) } } ?: throw Exception("파일을 열 수 없습니다.")
            val parsed = if (epub) parseEpub(dest, id) else ParsedBook(dest.readText(Charsets.UTF_8), emptyList(), null)
            val b = Book(id, displayName.substringBeforeLast('.'), "작가명", parsed.text, stored, parsed.coverFileName, parsed.chapters, genre = "기타")
            books.add(0, b); saveBooks(); openBook(0)
            Toast.makeText(this, "책을 앱에 보관했어요. 원본을 삭제해도 읽을 수 있습니다.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            copied?.delete(); Toast.makeText(this, "책을 추가하지 못했습니다: ${e.message ?: "오류"}", Toast.LENGTH_LONG).show()
        }
    }

    private data class ParsedBook(val text: String, val chapters: List<Chapter>, val coverFileName: String?)
    private fun parseEpub(file: File, id: String = file.nameWithoutExtension): ParsedBook {
        ZipFile(file).use { zip ->
            fun readEntry(path: String): String = zip.getEntry(path)?.let { zip.getInputStream(it).bufferedReader(Charsets.UTF_8).use { r -> r.readText() } } ?: ""
            fun clean(html: String): String = html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>"), "\n\n")
                .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace(Regex("[ \\t]+"), " ").trim()
            val container = readEntry("META-INF/container.xml")
            val opfPath = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(container)?.groupValues?.get(1)
                ?: zip.entries().asSequence().firstOrNull { it.name.endsWith(".opf", true) }?.name
            if (opfPath == null) return ParsedBook("EPUB 목차 정보를 찾지 못했습니다.", emptyList(), null)
            val opf = readEntry(opfPath); val base = opfPath.substringBeforeLast('/', "")
            fun resolve(href: String) = if (base.isBlank()) href.substringBefore('#') else "$base/${href.substringBefore('#')}"
            val manifest = mutableMapOf<String, Pair<String, String>>()
            val itemRegex = Regex("<item\\b([^>]*)/?>", RegexOption.IGNORE_CASE)
            for (m in itemRegex.findAll(opf)) {
                val attrs = m.groupValues[1]
                val itemId = Regex("id=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val href = Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val props = Regex("properties=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: ""
                manifest[itemId] = Pair(resolve(href), props)
            }
            var coverPath: String? = manifest.values.firstOrNull { it.second.split(' ').contains("cover-image") }?.first
            if (coverPath == null) {
                val coverId = Regex("<meta\\b[^>]*name=['\"]cover['\"][^>]*content=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(opf)?.groupValues?.get(1)
                if (coverId != null) coverPath = manifest[coverId]?.first
            }
            var coverName: String? = null
            if (coverPath != null) {
                val entry = zip.getEntry(coverPath)
                if (entry != null) {
                    val suffix = coverPath.substringAfterLast('.', "jpg").take(5)
                    coverName = "${id}_cover.$suffix"
                    zip.getInputStream(entry).use { input -> FileOutputStream(File(bookDir(), coverName)).use { output -> input.copyTo(output) } }
                }
            }
            val titleByHref = mutableMapOf<String, String>()
            val navItem = manifest.values.firstOrNull { it.second.split(' ').contains("nav") }?.first
            if (navItem != null) {
                val navHtml = readEntry(navItem)
                val navBase = navItem.substringBeforeLast('/', "")
                val navRegex = Regex("<a\\b[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                for (m in navRegex.findAll(navHtml)) {
                    val href = m.groupValues[1].substringBefore('#')
                    val full = if (href.startsWith("/")) href.removePrefix("/") else if (navBase.isBlank()) href else "$navBase/$href"
                    titleByHref[full] = clean(m.groupValues[2]).replace(Regex("\\s+"), " ").take(100)
                }
            }
            if (titleByHref.isEmpty()) {
                val ncxPath = manifest.values.firstOrNull { it.first.endsWith(".ncx", true) }?.first
                if (ncxPath != null) {
                    val ncx = readEntry(ncxPath); val ncxBase = ncxPath.substringBeforeLast('/', "")
                    val navPoint = Regex("<navPoint\\b.*?</navPoint>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    for (m in navPoint.findAll(ncx)) {
                        val href = Regex("<content\\b[^>]*src=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(m.value)?.groupValues?.get(1)?.substringBefore('#') ?: continue
                        val label = Regex("<text>(.*?)</text>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(m.value)?.groupValues?.get(1)?.let { clean(it) } ?: continue
                        val full = if (href.startsWith("/")) href.removePrefix("/") else if (ncxBase.isBlank()) href else "$ncxBase/$href"
                        titleByHref[full] = label
                    }
                }
            }
            val spine = Regex("<itemref\\b[^>]*idref=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).findAll(opf).mapNotNull { manifest[it.groupValues[1]]?.first }.toList()
            val chapters = spine.mapNotNull { path ->
                val html = readEntry(path); if (html.isBlank()) null else {
                    val title = titleByHref[path] ?: Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)?.let { clean(it) }?.take(100) ?: "본문 ${spine.indexOf(path) + 1}"
                    val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    Chapter(title, clean(body))
                }
            }
            val finalChapters = chapters.ifEmpty {
                zip.entries().asSequence().filter { !it.isDirectory && it.name.endsWith(".xhtml", true) }.mapNotNull { e ->
                    val html = readEntry(e.name); val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    clean(body).takeIf { it.isNotBlank() }?.let { Chapter(e.name.substringAfterLast('/').substringBeforeLast('.'), it) }
                }.toList()
            }
            val text = finalChapters.joinToString("\n\n") { it.text }.ifBlank { "EPUB 본문을 찾지 못했습니다." }
            return ParsedBook(text, finalChapters, coverName)
        }
    }

    private fun openBook(i: Int) {
        if (i !in books.indices) return
        stopAuto(); stopTts(); current = i
        readerCurrentPage = getSavedReaderPage(books[i].id).coerceAtLeast(0)
        readerTotalPages = 1; readerPageHistory.clear(); root.removeAllViews(); root.setPadding(0, 0, 0, 0); root.setBackgroundColor(paper)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(9), dp(14), dp(9)); setBackgroundColor(paper) }
        fun topIcon(glyph: String, desc: String, action: () -> Unit) = TextView(this).apply {
            text = glyph; contentDescription = desc; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(ink); setPadding(dp(10), dp(5), dp(10), dp(5)); setOnClickListener { action() }
        }
        top.addView(topIcon("‹", "서재로", ::showShelf), LinearLayout.LayoutParams(dp(48), dp(44)))
        top.addView(label(books[current].title, 13f, ink, true).apply { gravity = Gravity.CENTER; maxLines = 1 }, LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(topIcon("⌕", "본문 검색", ::search), LinearLayout.LayoutParams(dp(46), dp(44)))
        top.addView(topIcon("♧", "책갈피", ::bookmark), LinearLayout.LayoutParams(dp(46), dp(44)))
        add(root, top)
        val w = WebView(this).apply {
            setBackgroundColor(paper); settings.javaScriptEnabled = true
            isVerticalScrollBarEnabled = !pageMode; isHorizontalScrollBarEnabled = false
            addJavascriptInterface(ReaderBridge(), "ReaderBridge")
        }
        web = w; root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        ttsPlayerBar = buildTtsPlayer().also { it.visibility = View.GONE; root.addView(it) }
        val progressArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(3), dp(12), dp(2))
            setBackgroundColor(if (darkMode) Color.rgb(29,29,31) else Color.rgb(244,241,234))
        }
        val progressLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        pageSeekBar = SeekBar(this).apply {
            max = 0
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(if (darkMode) Color.rgb(174,190,187) else accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(if (darkMode) Color.rgb(174,190,187) else accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) pageCountLabel?.text = "${value + 1} / $readerTotalPages" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { seekBar?.let { web?.evaluateJavascript("goPage(${it.progress})", null) } }
            })
        }
        progressLine.addView(pageSeekBar, LinearLayout.LayoutParams(0, dp(30), 1f))
        val backPosition = TextView(this).apply {
            text = "↶"; textSize = 23f; gravity = Gravity.CENTER; contentDescription = "이전 독서 위치로 돌아가기"
            setTextColor(if (darkMode) Color.rgb(210,218,215) else Color.rgb(91,111,107))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (darkMode) Color.rgb(55,59,61) else Color.rgb(224,231,227)); setStroke(dp(1), if (darkMode) Color.rgb(100,119,115) else Color.rgb(153,174,168)) }
            setOnClickListener {
                if (readerPageHistory.isNotEmpty()) {
                    val previous = readerPageHistory.removeLast()
                    web?.evaluateJavascript("goPage($previous)", null)
                } else Toast.makeText(this@MainActivity, "이전 독서 위치가 없어요", Toast.LENGTH_SHORT).show()
            }
        }
        progressLine.addView(backPosition, LinearLayout.LayoutParams(dp(38), dp(38)).apply { leftMargin = dp(8) })
        progressArea.addView(progressLine)
        pageCountLabel = TextView(this).apply { text = "1 / 1"; textSize = 10f; setTextColor(muted); setPadding(dp(2), 0, 0, dp(2)) }
        progressArea.addView(pageCountLabel)
        root.addView(progressArea)
        val bar = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER; setPadding(dp(5), dp(7), dp(5), dp(7)); setBackgroundColor(if (darkMode) Color.rgb(29,29,31) else Color.rgb(244,241,234)) }
        val actions = listOf("목차" to "☷", "듣기" to "⊙", "자동스크롤" to "↕", "독서노트" to "▣", "보기 설정" to "T", "뷰어 설정" to "⚙")
        actions.forEachIndexed { n, pair ->
            val item = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(dp(2), dp(2), dp(2), dp(2)); setOnClickListener { when (n) { 0 -> toc(); 1 -> ttsControls(); 2 -> toggleAuto(); 3 -> showBookmarkList(); 4 -> viewSettings(); 5 -> readerSettings() } } }
            item.addView(label(pair.second, 19f, ink, true).apply { gravity = Gravity.CENTER })
            item.addView(label(pair.first, 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
            bar.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        add(root, bar)
        // Load an already-downloaded model while the reader is open, so the first tap does not pay the model-load delay.
        if (com.ouor.supertonic.data.ModelAssets.isReady(this) && aiEngine == null && !aiPreparing) preloadAiEngine()
    }

    private fun markPage(raw: String): Int? = raw.removePrefix("page:").substringBefore("|").toIntOrNull()
    private fun markChapter(raw: String): String = raw.substringAfter("|chapter:", "").takeIf { it.isNotBlank() } ?: "본문"

    private fun render() {
        val b = books.getOrNull(current) ?: return
        val paragraphList = b.text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
        val chapterAt = mutableMapOf<Int, String>()
        var paragraphCursor = 0
        b.chapters.forEach { chapter ->
            chapterAt[paragraphCursor] = chapter.title
            paragraphCursor += chapter.text.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }
        }
        val paras = paragraphList.mapIndexed { idx, it ->
            val heading = chapterAt[idx]?.let { title -> "<h2 data-chapter=\"${esc(title)}\">${esc(title)}</h2>" } ?: ""
            heading + "<p id=\"para$idx\" data-para=\"$idx\">${esc(it).replace("\n", "<br>")}</p>"
        }.joinToString("")
        val bg = if (darkMode) "#232325" else "#F9F7F1"; val fg = if (darkMode) "#E8E5DE" else "#393630"
        val layout = if (pageMode) """
            html,body{width:100%;height:100%;overflow:hidden}
            body{width:100vw;height:100vh;overflow-x:auto;overflow-y:hidden;column-width:calc(100vw - 48px);column-gap:48px;column-fill:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;}
        """ else """
            html,body{min-height:100%;overflow-x:hidden;overflow-y:auto}
            body{column-width:auto}
        """
        val marked = b.marks.mapNotNull { markPage(it) }.distinct().joinToString(",")
        val html = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><style>
            *{box-sizing:border-box}html,body{margin:0;background:$bg;color:$fg}
            body{font-family:serif;font-size:${font}px;line-height:$line;padding:30px 24px 55px;word-break:keep-all;overflow-wrap:anywhere}
            h2{font-size:1.15em;margin:0 0 1.4em;font-weight:700;break-after:avoid}
            p{margin:0 0 1.6em;text-align:justify;break-inside:avoid}
            #bookmarkRibbon{position:fixed;z-index:99;right:12px;top:0;width:24px;height:48px;background:#c62828;clip-path:polygon(0 0,100% 0,100% 100%,50% 78%,0 100%);display:none}
            .ttsCurrent{background:#f5df70!important;color:#29251d!important;border-radius:4px;box-shadow:0 0 0 2px rgba(245,223,112,.22);transition:background-color .12s ease}
            $layout
        </style></head><body>$paras<div id="bookmarkRibbon"></div>
        <script>
        const markedPages=[$marked];
        const savedPage=${getSavedReaderPage(b.id).coerceAtLeast(0)};
        function pageIndex(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/(window.innerWidth)))" else "Math.max(0,Math.floor(window.scrollY/Math.max(1,window.innerHeight)))"};}
        function totalPages(){const size=${if (pageMode) "Math.max(1,window.innerWidth)" else "Math.max(1,window.innerHeight)"};const extent=${if (pageMode) "document.body.scrollWidth" else "Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)"};return Math.max(1,Math.ceil(extent/size));}
        function notifyPage(){try{if(window.ReaderBridge)ReaderBridge.onPageChanged(pageIndex(),totalPages());}catch(e){}}
        function updateRibbon(){document.getElementById('bookmarkRibbon').style.display=markedPages.includes(pageIndex())?'block':'none';notifyPage();}
        function goPage(n){const max=totalPages()-1;n=Math.max(0,Math.min(max,Number(n)||0));if(${pageMode})document.body.scrollTo({left:n*window.innerWidth,behavior:'auto'});else window.scrollTo({top:n*window.innerHeight,behavior:'auto'});updateRibbon();}
        function currentChapterTitle(){
          const heads=Array.from(document.querySelectorAll('h2[data-chapter]'));
          let found='본문';
          for(const h of heads){const r=h.getBoundingClientRect();const passed=${pageMode}?(r.left < window.innerWidth):(r.top < window.innerHeight);if(passed)found=h.dataset.chapter;else break;}
          return found;
        }
        function currentPageText(){
          if(${pageMode}){const w=window.innerWidth;return Array.from(document.querySelectorAll('p')).filter(p=>{const r=p.getBoundingClientRect();return r.right>0&&r.left<w;}).map(p=>p.innerText).join('\n');}
          const y=window.scrollY;const h=window.innerHeight;return Array.from(document.querySelectorAll('p')).filter(p=>{const r=p.getBoundingClientRect();return r.bottom>0&&r.top<h;}).map(p=>p.innerText).join('\n');
        }
        function normText(v){return (v||'').replace(/\s+/g,' ').trim();}
        function highlightText(t){
          document.querySelectorAll('.ttsCurrent').forEach(e=>e.classList.remove('ttsCurrent'));
          const key=normText(t).slice(0,Math.min(16,normText(t).length));
          const p=Array.from(document.querySelectorAll('p')).find(e=>normText(e.innerText).includes(key));
          if(p){p.classList.add('ttsCurrent');if(${pageMode}){const left=p.getBoundingClientRect().left+document.body.scrollLeft;const target=Math.max(0,Math.floor(left/window.innerWidth));document.body.scrollTo({left:target*window.innerWidth,behavior:'auto'});}else{p.scrollIntoView({block:'center',behavior:'auto'});}}
          return !!p;
        }
        if(${pageMode}){
          let sx=0,sy=0;
          document.addEventListener('touchstart',e=>{if(e.touches.length===1){sx=e.touches[0].clientX;sy=e.touches[0].clientY;}},{passive:true});
          document.addEventListener('touchend',e=>{if(!e.changedTouches.length)return;const dx=e.changedTouches[0].clientX-sx;const dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){const w=window.innerWidth;const next=Math.max(0,Math.round(document.body.scrollLeft/w)+(dx<0?1:-1));document.body.scrollTo({left:next*w,behavior:'smooth'});setTimeout(updateRibbon,220);}},{passive:true});
        }
        window.addEventListener('scroll',updateRibbon);window.addEventListener('resize',()=>setTimeout(updateRibbon,80));
        // Restore the last page only after the document has its final layout, then publish progress.
        setTimeout(()=>{goPage(savedPage);},180);
        setTimeout(()=>{goPage(savedPage);updateRibbon();},520);
        </script></body></html>"""
        web?.setBackgroundColor(paper)
        web?.isVerticalScrollBarEnabled = !pageMode
        web?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun getSavedReaderPage(bookId: String): Int =
        getSharedPreferences("reader_positions", MODE_PRIVATE).getInt(bookId, 0)

    private fun saveReaderPage(bookId: String, page: Int) {
        getSharedPreferences("reader_positions", MODE_PRIVATE).edit().putInt(bookId, page.coerceAtLeast(0)).apply()
    }

    private inner class ReaderBridge {
        @JavascriptInterface fun onPageChanged(page: Int, total: Int) {
            runOnUiThread {
                val safeTotal = total.coerceAtLeast(1)
                val safePage = page.coerceIn(0, safeTotal - 1)
                if (safePage != readerCurrentPage) {
                    if (readerCurrentPage in 0 until readerTotalPages && (readerPageHistory.isEmpty() || readerPageHistory.peekLast() != readerCurrentPage)) {
                        readerPageHistory.addLast(readerCurrentPage)
                        while (readerPageHistory.size > 30) readerPageHistory.removeFirst()
                    }
                    readerCurrentPage = safePage
                }
                readerTotalPages = safeTotal
                books.getOrNull(current)?.let { book -> saveReaderPage(book.id, safePage) }
                pageSeekBar?.let { seek ->
                    seek.max = (safeTotal - 1).coerceAtLeast(0)
                    if (!seek.isPressed) seek.progress = safePage
                }
                pageCountLabel?.text = "${safePage + 1} / $safeTotal"
            }
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun bookmark() {
        val b = books.getOrNull(current) ?: return
        web?.evaluateJavascript("""(function(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/window.innerWidth))" else "Math.max(0,Math.floor(window.scrollY/window.innerHeight))"};})()""") { value ->
            val page = value?.trim('"')?.toIntOrNull() ?: 0
            web?.evaluateJavascript("currentChapterTitle()") { titleRaw ->
                val chapter = try { (org.json.JSONTokener(titleRaw ?: "\"본문\"").nextValue() as? String) ?: "본문" } catch (_: Exception) { "본문" }
                val old = b.marks.firstOrNull { markPage(it) == page }
                if (old != null) b.marks.remove(old) else b.marks.add("page:$page|chapter:${chapter.replace("|", " ")}")
                saveBooks(); render()
                web?.evaluateJavascript("setTimeout(()=>goPage($page),180)", null)
                Toast.makeText(this, if (old == null) "이 페이지를 책갈피에 추가했어요" else "책갈피를 해제했어요", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun showBookmarkList() {
        val b = books.getOrNull(current) ?: return
        val entries = b.marks.mapNotNull { raw -> markPage(raw)?.let { page -> Triple(page, markChapter(raw), raw) } }.distinctBy { it.first }.sortedBy { it.first }.map { mark ->
            val page = mark.first
            val note = b.notes.firstOrNull { raw ->
                val o = runCatching { JSONObject(raw) }.getOrNull(); o?.optInt("page", -1) == page
            }?.let { runCatching { JSONObject(it).optString("text") }.getOrNull() }
            Triple(page, "${mark.second} · ${page + 1}페이지", note)
        }
        if (entries.isEmpty()) { AlertDialog.Builder(this).setTitle("책갈피").setMessage("저장된 책갈피가 없습니다.").setPositiveButton("확인", null).show(); return }
        val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val scroll = ScrollView(this); scroll.addView(box)
        var dialogRef: AlertDialog? = null
        entries.forEach { item ->
            val card = LinearLayout(this).apply { orientation = 1; setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(if (darkMode) Color.rgb(55,55,57) else Color.rgb(248,246,241), 8) }
            card.addView(label("${item.second}", 15f, ink, true))
            if (!item.third.isNullOrBlank()) card.addView(label("✉️ ${item.third}", 13f, muted).apply { setPadding(0, dp(6), 0, 0) })
            card.setOnClickListener { web?.evaluateJavascript("goPage(${item.first})", null); dialogRef?.dismiss() }
            card.setOnLongClickListener {
                val opts = arrayOf("이 페이지로 이동", "메모 추가/수정", "책갈피 삭제")
                AlertDialog.Builder(this).setItems(opts) { _, which -> when(which) {
                    0 -> web?.evaluateJavascript("goPage(${item.first})", null)
                    1 -> editBookmarkNote(item.first)
                    2 -> { b.marks.removeAll { markPage(it) == item.first }; b.notes.removeAll { runCatching { JSONObject(it).optInt("page", -1) == item.first }.getOrDefault(false) }; saveBooks(); showBookmarkList() }
                } }.show(); true
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); box.addView(card, lp)
        }
        dialogRef = AlertDialog.Builder(this).setTitle("책갈피 ${entries.size}개 · 길게 눌러 편집").setView(scroll).setPositiveButton("닫기", null).create()
        dialogRef?.show()
    }

    private fun editBookmarkNote(page: Int) {
        val b = books.getOrNull(current) ?: return
        val idx = b.notes.indexOfFirst { runCatching { JSONObject(it).optInt("page", -1) == page }.getOrDefault(false) }
        val old = if (idx >= 0) runCatching { JSONObject(b.notes[idx]).optString("text") }.getOrDefault("") else ""
        val edit = EditText(this).apply { hint = "이 책갈피에 메모"; minLines = 3; setText(old) }
        AlertDialog.Builder(this).setTitle("${page + 1}페이지 메모").setView(edit).setPositiveButton("저장") { _, _ ->
            val value = edit.text.toString().trim()
            if (idx >= 0) b.notes.removeAt(idx)
            if (value.isNotBlank()) b.notes.add(JSONObject().put("page", page).put("text", value).toString())
            saveBooks()
        }.setNegativeButton("취소", null).show()
    }

    private fun search() { val e = EditText(this).apply { hint = "검색할 내용" }; AlertDialog.Builder(this).setTitle("책 속 내용 검색").setView(e).setPositiveButton("검색") { _, _ -> web?.findAllAsync(e.text.toString()) }.setNegativeButton("취소", null).show() }

    private fun toc() {
        val b = books.getOrNull(current) ?: return
        if (b.chapters.isNotEmpty()) {
            val entries = b.chapters.map { it.title }.toTypedArray()
            AlertDialog.Builder(this).setTitle("EPUB 원본 목차").setItems(entries) { _, which ->
                val target = b.chapters.take(which).sumOf { it.text.split(Regex("\\n\\s*\\n")).count { p -> p.isNotBlank() } }
                web?.evaluateJavascript("document.getElementById('para$target')?.scrollIntoView();", null)
            }.setNegativeButton("닫기", null).show()
        } else {
            AlertDialog.Builder(this).setTitle("목차").setMessage("이 TXT 파일에는 원본 목차가 없습니다.").setPositiveButton("확인", null).show()
        }
    }
    private fun notes() {
        val b = books.getOrNull(current) ?: return
        fun pageNow(done: (Int) -> Unit) {
            web?.evaluateJavascript("""(function(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/window.innerWidth))" else "Math.max(0,Math.floor(window.scrollY/window.innerHeight))"};})()""") { v -> done(v?.trim('"')?.toIntOrNull() ?: 0) }
        }
        fun showNotes() {
            val parsed = b.notes.mapIndexed { i, raw ->
                try { val o = JSONObject(raw); Pair(o.optInt("page", 0), o.optString("text")) }
                catch (_: Exception) { Pair(0, raw) }
            }
            val labels = parsed.mapIndexed { i, item -> "${i + 1}. ${if (item.first > 0) "${item.first + 1}쪽 · " else ""}${item.second}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("독서노트 · ${b.notes.size}개")
                .setItems(labels.ifEmpty { arrayOf("저장된 메모가 없습니다.") }) { _, which ->
                    if (which < b.notes.size) editNote(which)
                }
                .setPositiveButton("메모 추가") { _, _ -> pageNow { page ->
                    val e = EditText(this).apply { hint = "메모를 입력하세요"; minLines = 3 }
                    AlertDialog.Builder(this).setTitle("${page + 1}쪽 메모 추가").setView(e)
                        .setPositiveButton("저장") { _, _ ->
                            val value = e.text.toString().trim(); if (value.isNotEmpty()) {
                                b.notes.add(JSONObject().put("page", page).put("text", value).toString()); saveBooks()
                            }
                        }.setNegativeButton("취소", null).show()
                } }.setNegativeButton("닫기", null).show()
        }
        showNotes()
    }

    private fun editNote(index: Int) {
        val b = books.getOrNull(current) ?: return
        if (index !in b.notes.indices) return
        val raw = b.notes[index]
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("page", 0).put("text", raw) }
        val e = EditText(this).apply { hint = "메모를 입력하세요"; minLines = 3; setText(obj.optString("text")) }
        AlertDialog.Builder(this).setTitle("독서 메모 수정").setView(e)
            .setPositiveButton("저장") { _, _ ->
                val value = e.text.toString().trim()
                if (value.isBlank()) b.notes.removeAt(index)
                else b.notes[index] = JSONObject().put("page", obj.optInt("page", 0)).put("text", value).toString()
                saveBooks()
            }.setNeutralButton("삭제") { _, _ ->
                AlertDialog.Builder(this).setMessage("이 메모를 삭제할까요?").setPositiveButton("삭제") { _, _ -> b.notes.removeAt(index); saveBooks() }.setNegativeButton("취소", null).show()
            }.setNegativeButton("취소", null).show()
    }

    private fun buildTtsPlayer(): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = 1
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.rgb(8,8,9))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label(if (aiPreparing) "AI 음성 준비 중" else "AI 책 읽어주기", 12f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        val voice = label(selectedVoice, 12f, ink, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(10), dp(6), dp(10), dp(6)); background = bg(if (darkMode) Color.rgb(55,55,58) else Color.rgb(222,216,205), 16)
            setOnClickListener { chooseAiVoice() }
        }
        header.addView(voice)
        val speed = label("${aiSpeed}×", 12f, ink, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { chooseAiSpeed() }
        }
        header.addView(speed)
        panel.addView(header)

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }
        fun control(glyph: String, action: () -> Unit, primary: Boolean = false) = TextView(this).apply {
            text = glyph; textSize = if (primary) 22f else 18f; gravity = Gravity.CENTER
            setTextColor(if (primary) Color.WHITE else ink)
            background = bg(if (primary) accent else if (darkMode) Color.rgb(48,48,51) else Color.rgb(229,225,217), 24)
            setOnClickListener { action() }
        }
        row.addView(control("|◀", { if (aiIndex > 0) { aiIndex = (aiIndex - 1).coerceAtLeast(0); aiPaused = false; playAiChunks() } }), LinearLayout.LayoutParams(dp(42), dp(42)))
        val playGlyph = if (aiPaused || aiPlaybackJob?.isActive != true) "▶" else "Ⅱ"
        val play = control(playGlyph, { if (aiPaused || aiPlaybackJob?.isActive != true) resumeAiTts() else pauseAiTts() }, true)
        val playLp = LinearLayout.LayoutParams(dp(48), dp(48)); playLp.leftMargin = dp(18); playLp.rightMargin = dp(18)
        row.addView(play, playLp)
        row.addView(control("▶|", { if (aiIndex < aiChunks.lastIndex) { aiIndex++; aiPaused = false; playAiChunks() } }), LinearLayout.LayoutParams(dp(42), dp(42)))
        val stop = control("■", { stopTts() })
        val stopLp = LinearLayout.LayoutParams(dp(38), dp(38)); stopLp.leftMargin = dp(18)
        row.addView(stop, stopLp)
        panel.addView(row)
        return panel
    }

    private fun updateTtsPlayer() {
        ttsPlayerBar?.visibility = if (aiChunks.isNotEmpty() || aiPlaybackJob?.isActive == true) View.VISIBLE else View.GONE
        val bar = ttsPlayerBar ?: return
        val fresh = buildTtsPlayer()
        bar.removeAllViews()
        while (fresh.childCount > 0) {
            val child = fresh.getChildAt(0)
            fresh.removeViewAt(0)
            bar.addView(child)
        }
    }

    private fun ttsControls() {
        val options = arrayOf("현재 페이지부터 AI 음성으로 읽기", "일시정지", "이어 읽기", "남성 목소리 선택 (현재 $selectedVoice)", "읽기 속도 설정", "읽기 중지")
        AlertDialog.Builder(this).setTitle("AI 책 읽어주기 · Supertonic")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startAiTts(true)
                    1 -> pauseAiTts()
                    2 -> resumeAiTts()
                    3 -> chooseAiVoice()
                    4 -> chooseAiSpeed()
                    5 -> stopTts()
                }
            }.setNegativeButton("닫기", null).show()
    }

    private fun chooseAiVoice() {
        val voices = arrayOf("M1", "M2", "M3", "M4", "M5")
        AlertDialog.Builder(this).setTitle("남성 AI 목소리 선택")
            .setSingleChoiceItems(voices, voices.indexOf(selectedVoice).coerceAtLeast(0)) { dialog, which ->
                selectedVoice = voices[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putString("voice", selectedVoice).apply()
                dialog.dismiss(); updateTtsPlayer()
                Toast.makeText(this, "$selectedVoice 목소리로 설정했어요.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("취소", null).show()
    }

    private fun chooseAiSpeed() {
        val speeds = floatArrayOf(0.8f, 0.9f, 1.0f, 1.05f, 1.2f, 1.35f)
        val labels = arrayOf("0.8배", "0.9배", "1.0배", "1.05배", "1.2배", "1.35배")
        val selected = speeds.indices.minByOrNull { kotlin.math.abs(speeds[it] - aiSpeed) } ?: 3
        AlertDialog.Builder(this).setTitle("읽기 속도")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                aiSpeed = speeds[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putFloat("speed", aiSpeed).apply()
                dialog.dismiss(); updateTtsPlayer()
            }.setNegativeButton("취소", null).show()
    }

    private fun startAiTts(restart: Boolean) {
        val book = books.getOrNull(current) ?: return
        if (restart) {
            web?.evaluateJavascript("currentPageText()") { raw ->
                val visible = try { org.json.JSONTokener(raw ?: "\"\"").nextValue() as? String ?: "" } catch (_: Exception) { "" }
                val anchor = normalizeForMatch(visible.substringBefore("\n")).take(16)
                val paragraphs = book.text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
                val startIndex = if (anchor.isNotBlank()) paragraphs.indexOfFirst { normalizeForMatch(it).contains(anchor) }.coerceAtLeast(0) else 0
                val source = paragraphs.drop(startIndex).joinToString("\n\n").ifBlank { book.text }
                val result = splitForSpeech(source)
                aiChunks = result.first
                aiParagraphEnds = result.second
                aiIndex = 0
                aiPaused = false
                updateTtsPlayer()
                ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
            } ?: run { prepareAllBookTts(book.text) }
            return
        }
        if (aiChunks.isEmpty()) prepareAllBookTts(book.text)
        else {
            aiPaused = false
            ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
        }
    }

    private fun prepareAllBookTts(text: String) {
        val result = splitForSpeech(text)
        aiChunks = result.first; aiParagraphEnds = result.second; aiIndex = 0; aiPaused = false
        updateTtsPlayer()
        ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
    }

    private fun normalizeForMatch(text: String) = text.replace(Regex("\\s+"), "").replace(Regex("[“”‘’\"'.,!?…:;]"), "")

    /** Keeps paragraph boundaries so a deliberate 100ms pause can be inserted only between paragraphs. */
    private fun splitForSpeech(text: String): Pair<List<String>, Set<Int>> {
        val chunks = mutableListOf<String>()
        val paragraphEnds = mutableSetOf<Int>()
        val paragraphs = text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
        paragraphs.forEach { paragraph ->
            val normalized = paragraph.replace(Regex("\\s+"), " ").trim()
            val sentences = normalized.split(Regex("(?<=[.!?。！？])\\s*")).filter { it.isNotBlank() }
            var group = StringBuilder()
            sentences.forEach { sentence ->
                if (group.isNotEmpty() && group.length + sentence.length + 1 > 180) {
                    chunks.add(group.toString().trim()); group = StringBuilder()
                }
                if (group.isNotEmpty()) group.append(" ")
                group.append(sentence)
            }
            if (group.isNotEmpty()) {
                val finalText = group.toString().trim()
                val spokenText = if (finalText.lastOrNull()?.let { it in ".!?。！？…" } == true) finalText else "$finalText。"
                chunks.add(spokenText)
            }
            if (chunks.isNotEmpty()) paragraphEnds.add(chunks.lastIndex)
        }
        return chunks to paragraphEnds
    }

    private fun resumeAiTts() {
        if (aiChunks.isEmpty()) { startAiTts(true); return }
        aiPaused = false
        ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
    }

    private fun pauseAiTts() {
        aiPaused = true
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        updateTtsPlayer(); stopPlaybackService(); Toast.makeText(this, "일시정지했어요.", Toast.LENGTH_SHORT).show()
    }

    private fun playAiChunks() {
        val engine = aiEngine ?: return
        startPlaybackService()
        aiPlaybackJob?.cancel()
        aiPlaybackJob = aiScope.launch {
            try {
                var pcm: FloatArray? = null
                suspend fun synthesize(index: Int): FloatArray = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val style = com.ouor.supertonic.tts.VoiceStyle.load(
                        com.ouor.supertonic.data.ModelAssets.voiceStyleFile(this@MainActivity, selectedVoice)
                    )
                    engine.synthesize(aiChunks[index], "ko", style, totalStep = 8, speed = aiSpeed, silenceDuration = 0.1f).wav
                }
                if (aiIndex < aiChunks.size) pcm = synthesize(aiIndex)
                while (!aiPaused && aiIndex < aiChunks.size) {
                    val index = aiIndex
                    val chunk = aiChunks[index]
                    // Highlight is applied after synthesis but before audio starts; wait for WebView JS to finish.
                    val highlighted = kotlinx.coroutines.CompletableDeferred<Unit>()
                    runOnUiThread {
                        val js = "highlightText(${JSONObject.quote(chunk)})"
                        web?.evaluateJavascript(js) { highlighted.complete(Unit) } ?: highlighted.complete(Unit)
                    }
                    highlighted.await()
                    val nextPcm = if (index + 1 < aiChunks.size) kotlinx.coroutines.coroutineScope {
                        val nextDeferred = async(kotlinx.coroutines.Dispatchers.IO) {
                            val style = com.ouor.supertonic.tts.VoiceStyle.load(
                                com.ouor.supertonic.data.ModelAssets.voiceStyleFile(this@MainActivity, selectedVoice)
                            )
                            engine.synthesize(aiChunks[index + 1], "ko", style, totalStep = 8, speed = aiSpeed, silenceDuration = 0.1f).wav
                        }
                        aiPlayer?.play(pcm ?: FloatArray(0), null)
                        nextDeferred.await()
                    } else {
                        aiPlayer?.play(pcm ?: FloatArray(0), null)
                        null
                    }
                    aiIndex++
                    runOnUiThread { updateTtsPlayer() }
                    if (aiParagraphEnds.contains(index) && aiIndex < aiChunks.size) kotlinx.coroutines.delay(100)
                    pcm = nextPcm
                }
                if (aiIndex >= aiChunks.size) {
                    aiChunks = emptyList(); aiParagraphEnds = emptySet(); aiIndex = 0
                    runOnUiThread { stopPlaybackService(); handler.postDelayed({ updateTtsPlayer() }, 150) }
                    web?.evaluateJavascript("document.querySelectorAll('.ttsCurrent').forEach(e=>e.classList.remove('ttsCurrent'))", null)
                    Toast.makeText(this@MainActivity, "읽기가 끝났어요.", Toast.LENGTH_SHORT).show()
                }
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Pause/stop requested by the user.
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "AI 음성 재생 오류: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
        updateTtsPlayer()
    }

    private fun ensureAiEngine(onReady: () -> Unit) {
        if (aiEngine != null) { onReady(); return }
        if (aiPreparing) { aiEngineReadyCallbacks.add(onReady); return }
        if (!com.ouor.supertonic.data.ModelAssets.isReady(this)) {
            AlertDialog.Builder(this).setTitle("AI 음성 모델 다운로드")
                .setMessage("처음 한 번만 약 400MB의 음성 모델을 다운로드합니다. 이후에는 인터넷 없이 사용할 수 있어요. Wi-Fi 연결을 권장합니다.")
                .setPositiveButton("다운로드") { _, _ -> downloadAiModel(onReady) }
                .setNegativeButton("취소", null).show()
        } else loadAiEngine(onReady)
    }

    private fun downloadAiModel(onReady: () -> Unit) {
        val progress = android.app.ProgressDialog(this).apply {
            setTitle("AI 음성 모델 다운로드")
            setMessage("다운로드 준비 중...")
            setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
            max = 100; setCancelable(false); show()
        }
        aiScope.launch {
            var completed = false
            try {
                com.ouor.supertonic.data.ModelDownloader(this@MainActivity).download().collect { state ->
                    when (state) {
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Running -> {
                            val percent = if (state.totalBytes > 0) ((state.downloadedBytes * 100) / state.totalBytes).toInt() else 0
                            progress.progress = percent
                            progress.setMessage("파일 ${state.fileIndex + 1}/${state.fileCount} 다운로드 중... $percent%")
                        }
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Done -> completed = true
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Failed -> throw IllegalStateException(state.message)
                    }
                }
                progress.dismiss()
                if (!completed) throw IllegalStateException("다운로드가 완료되지 않았습니다.")
                loadAiEngine(onReady)
            } catch (e: Exception) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, "모델 다운로드 실패: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun preloadAiEngine() {
        if (aiPreparing || aiEngine != null) return
        loadAiEngine({}, silent = true)
    }

    private fun loadAiEngine(onReady: () -> Unit, silent: Boolean = false) {
        aiPreparing = true
        if (!silent) Toast.makeText(this, "AI 음성 엔진을 준비하고 있어요. 잠시 기다려 주세요.", Toast.LENGTH_SHORT).show()
        aiScope.launch {
            try {
                val engine = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.ouor.supertonic.tts.SupertonicTts.load(com.ouor.supertonic.data.ModelAssets.onnxDir(this@MainActivity))
                }
                aiEngine?.close()
                aiEngine = engine
                aiPlayer = com.ouor.supertonic.audio.PcmPlayer(engine.sampleRate)
                // Warm up the inference session once; this moves one-time initialization away from the first spoken sentence.
                runCatching {
                    val style = com.ouor.supertonic.tts.VoiceStyle.load(com.ouor.supertonic.data.ModelAssets.voiceStyleFile(this@MainActivity, selectedVoice))
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { engine.synthesize("음성 준비", "ko", style, totalStep = 4, speed = 1.0f, silenceDuration = 0.0f) }
                }
                aiPreparing = false
                onReady()
                val callbacks = aiEngineReadyCallbacks.toList(); aiEngineReadyCallbacks.clear()
                callbacks.forEach { it() }
            } catch (e: Exception) {
                aiPreparing = false
                aiEngineReadyCallbacks.clear()
                if (!silent) Toast.makeText(this@MainActivity, "AI 음성 엔진 오류: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startPlaybackService() {
        val intent = Intent(this, TtsPlaybackService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun stopPlaybackService() { stopService(Intent(this, TtsPlaybackService::class.java)) }

    private fun stopTts() {
        aiPaused = false
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        aiChunks = emptyList(); aiParagraphEnds = emptySet(); aiIndex = 0
        aiEngineReadyCallbacks.clear()
        ttsPlayerBar?.visibility = View.GONE
        stopPlaybackService()
    }

    private fun stopAuto() { auto = false; handler.removeCallbacks(autoTask) }
    private fun toggleAuto() {
        auto = !auto
        if (auto) handler.post(autoTask) else handler.removeCallbacks(autoTask)
        Toast.makeText(this, if (auto) "자동 스크롤 켜짐" else "자동 스크롤 꺼짐", Toast.LENGTH_SHORT).show()
    }
    private fun viewSettings() {
        val opts = arrayOf("페이지 넘김", "세로 스크롤", if (darkMode) "아이보리 모드로 전환" else "다크모드로 전환")
        AlertDialog.Builder(this).setTitle("읽기 방식 및 화면")
            .setSingleChoiceItems(opts, if (pageMode) 0 else 1) { d, n ->
                when (n) { 0 -> pageMode = true; 1 -> pageMode = false; 2 -> { darkMode = !darkMode; getSharedPreferences("reader", MODE_PRIVATE).edit().putBoolean("dark", darkMode).apply() } }
                render(); d.dismiss()
            }.show()
    }
    private fun readerSettings() {
        val opts = arrayOf("글자 크기 줄이기", "글자 크기 키우기", "줄 간격 변경")
        AlertDialog.Builder(this).setTitle("보기 설정").setItems(opts) { _, n ->
            when (n) { 0 -> font = (font - 1).coerceAtLeast(14); 1 -> font = (font + 1).coerceAtMost(32); 2 -> line = if (line < 2.0) 2.2 else 1.7 }
            render()
        }.show()
    }

    override fun onBackPressed() { if (web != null) showShelf() else super.onBackPressed() }
    override fun onDestroy() {
        stopAuto(); stopTts(); aiScope.cancel(); aiEngine?.close(); aiPlayer?.stop(); web?.destroy(); super.onDestroy()
    }
}
