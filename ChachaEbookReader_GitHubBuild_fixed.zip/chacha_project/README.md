# 차차의 서재

간단한 Android EPUB/TXT 리더 초기 프로젝트입니다.

## 빌드
GitHub Actions workflow는 이 프로젝트 ZIP을 풀고 Gradle을 설치한 뒤 `gradle assembleDebug`를 실행합니다. Gradle Wrapper 파일은 포함하지 않습니다.

## 현재 포함 기능
- EPUB/TXT 파일 선택 및 본문 표시
- EPUB 내 HTML/XHTML 파일의 텍스트 추출
- 책장 목록(앱 실행 중 메모리 유지)
- 글자 크기 및 줄 간격 조절
- Android 기본 TTS 한국어 읽기

## 제한
현재 초기 빌드용 최소 버전입니다. 책장 영구 저장, 표지/제목 편집, EPUB 정식 OPF/NCX/nav 목차, 페이지 넘김, 형광펜/책갈피, AI TTS는 아직 구현되지 않았습니다. DRM EPUB은 지원하지 않습니다.
