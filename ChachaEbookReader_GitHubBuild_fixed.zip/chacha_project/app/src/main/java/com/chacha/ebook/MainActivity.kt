package com.chacha.ebook

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.zip.ZipInputStream

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private val books = mutableListOf<Pair<String, String>>()
    private var currentText = ""
    private var fontSize = 18
    private var lineHeight = 1.8
    private val pickCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 12); setBackgroundColor(0xFFF7F5F2.toInt()) }
        val header = TextView(this).apply { text = "차차의 서재"; textSize = 25f; setTextColor(0xFF29252D.toInt()); gravity = Gravity.CENTER_VERTICAL; setPadding(4, 8, 4, 18) }
        root.addView(header)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("책 추가") { chooseBook() }, weight())
        actions.addView(button("책장") { showShelf() }, weight())
        actions.addView(button("읽어주기") { if (currentText.isNotBlank()) tts.speak(currentText.take(3500), TextToSpeech.QUEUE_FLUSH, null, "reader") }, weight())
        root.addView(actions)
        val settings = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        settings.addView(button("글자 −") { fontSize = (fontSize - 1).coerceAtLeast(12); render() }, weight())
        settings.addView(button("글자 +") { fontSize = (fontSize + 1).coerceAtMost(32); render() }, weight())
        settings.addView(button("줄 간격") { lineHeight = if (lineHeight < 2.0) 2.2 else 1.5; render() }, weight())
        root.addView(settings)
        web = WebView(this).apply { settings.javaScriptEnabled = false; setBackgroundColor(0xFFF7F5F2.toInt()) }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        showShelf()
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 13f; setOnClickListener { action() } }

    private fun chooseBook() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream")) }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated in Android API but supported")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        val name = queryName(uri)
        val text = if (name.lowercase().endsWith(".epub")) readEpub(uri) else readText(uri)
        books.removeAll { it.first == name }
        books.add(0, name to text)
        currentText = text
        render()
    }

    private fun queryName(uri: Uri): String = contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && idx >= 0) c.getString(idx) else "새 책"
    } ?: "새 책"

    private fun readText(uri: Uri): String = contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: "파일을 읽을 수 없습니다."

    private fun readEpub(uri: Uri): String {
        val parts = mutableListOf<Pair<Int, String>>()
        contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val n = entry.name.lowercase()
                    if (!entry.isDirectory && (n.endsWith(".html") || n.endsWith(".xhtml") || n.endsWith(".htm"))) {
                        val body = zip.readBytes().toString(Charsets.UTF_8)
                        val plain = body.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                            .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>"), "\n\n")
                            .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&amp;", "&")
                            .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                        parts.add((if (n.contains("nav")) 1 else 0) to plain)
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        }
        return parts.sortedBy { it.first }.joinToString("\n\n") { it.second }.ifBlank { "EPUB 본문을 찾지 못했습니다." }
    }

    private fun showShelf() {
        web.loadDataWithBaseURL(null, html("<h2>내 책장</h2><p>‘책 추가’를 눌러 EPUB 또는 TXT 파일을 불러오세요.</p>" + books.joinToString("") { "<p>📖 ${escape(it.first)}</p>" }), "text/html", "UTF-8", null)
    }

    private fun render() {
        if (currentText.isBlank()) { showShelf(); return }
        val paragraphs = currentText.split(Regex("\\n\\s*\\n")).joinToString("") { "<p>${escape(it).replace("\n", "<br>")}</p>" }
        web.loadDataWithBaseURL(null, html("<h2>읽는 중</h2>$paragraphs"), "text/html", "UTF-8", null)
    }

    private fun html(body: String) = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{background:#f7f5f2;color:#29252d;font-family:sans-serif;font-size:${fontSize}px;line-height:${lineHeight};padding:8px 10px}p{margin:0 0 1.4em}h2{font-size:1.25em}</style></head><body>$body</body></html>"""
    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale.KOREAN }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
