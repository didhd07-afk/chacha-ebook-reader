package com.chacha.ebook

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.JavascriptInterface
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.cancel
import java.util.zip.ZipFile
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private data class Chapter(val title: String, val text: String)
    private data class Book(
        val id: String, var title: String, var author: String, val text: String,
        val storedFileName: String, val coverFileName: String? = null,
        val chapters: List<Chapter> = emptyList(),
        val marks: MutableList<String> = mutableListOf(), val notes: MutableList<String> = mutableListOf()
    )

    private lateinit var root: LinearLayout
    private var aiEngine: com.ouor.supertonic.tts.SupertonicTts? = null
    private var aiPlayer: com.ouor.supertonic.audio.PcmPlayer? = null
    private val aiScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob())
    private var aiPlaybackJob: kotlinx.coroutines.Job? = null
    private var aiChunks: List<String> = emptyList()
    private var aiIndex = 0
    private var aiPaused = false
    private var selectedVoice = "M1"
    private var aiSpeed = 1.05f
    private var web: WebView? = null
    private var ttsPlayerBar: LinearLayout? = null
    private var sortMode = "recent"
    private val books = mutableListOf<Book>()
    private var current = -1
    private var font = 19
    private var line = 1.9
    private var pageMode = false
    private var pendingBookmark = false
    private var auto = false
    private var darkMode = false
    private val handler = Handler(Looper.getMainLooper())
    private val autoTask = object : Runnable {
        override fun run() {
            if (auto) {
                web?.scrollBy(0, dp(2))
                handler.postDelayed(this, 45)
            }
        }
    }
    private val paper get() = if (darkMode) Color.rgb(35, 35, 37) else Color.rgb(249, 247, 241)
    private val ink get() = if (darkMode) Color.rgb(232, 229, 222) else Color.rgb(48, 45, 42)
    private val muted = Color.rgb(139, 132, 123)
    private val accent = Color.rgb(126, 105, 88)
    private val pick = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkMode = getSharedPreferences("reader", MODE_PRIVATE).getBoolean("dark", false)
        selectedVoice = getSharedPreferences("ai_tts", MODE_PRIVATE).getString("voice", "M1") ?: "M1"
        sortMode = getSharedPreferences("library", MODE_PRIVATE).getString("sort", "recent") ?: "recent"
        aiSpeed = getSharedPreferences("ai_tts", MODE_PRIVATE).getFloat("speed", 1.05f)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)
        loadBooks()
        showShelf()
    }

    private fun bookDir() = File(filesDir, "books").apply { if (!exists()) mkdirs() }
    private fun saveBooks() {
        val arr = JSONArray()
        books.forEach { b ->
            arr.put(JSONObject().put("id", b.id).put("title", b.title).put("author", b.author)
                .put("file", b.storedFileName).put("cover", b.coverFileName ?: "")
                .put("marks", JSONArray(b.marks)).put("notes", JSONArray(b.notes)))
        }
        getSharedPreferences("library", MODE_PRIVATE).edit().putString("books", arr.toString()).apply()
    }

    private fun loadBooks() {
        books.clear()
        val raw = getSharedPreferences("library", MODE_PRIVATE).getString("books", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("file")
                val f = File(bookDir(), name)
                if (!f.exists()) continue
                val parsed = if (name.lowercase().endsWith(".epub")) parseEpub(f) else ParsedBook(f.readText(Charsets.UTF_8), emptyList(), null)
                val marks = mutableListOf<String>(); val ma = o.optJSONArray("marks") ?: JSONArray()
                for (j in 0 until ma.length()) marks.add(ma.optString(j))
                val notes = mutableListOf<String>(); val na = o.optJSONArray("notes") ?: JSONArray()
                for (j in 0 until na.length()) notes.add(na.optString(j))
                val cover = o.optString("cover", "").ifBlank { parsed.coverFileName }
                books.add(Book(o.getString("id"), o.optString("title", "새 책"), o.optString("author", "작가명"), parsed.text, name, cover, parsed.chapters, marks, notes))
            }
        } catch (_: Exception) {
            Toast.makeText(this, "저장된 서재 정보를 읽지 못했습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun bg(color: Int, r: Int = 12) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(5), dp(12), dp(5), dp(12)); background = bg(Color.rgb(65, 61, 57), 10); setOnClickListener { action() }
    }
    private fun add(parent: LinearLayout, v: View, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
    }

    private fun showShelf() {
        stopAuto(); stopTts()
        web?.destroy(); web = null; root.removeAllViews(); root.setPadding(dp(18), dp(20), dp(18), dp(12)); root.setBackgroundColor(Color.rgb(246, 246, 246))
        val top = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val title = LinearLayout(this).apply { orientation = 1 }
        title.addView(label("차차의 서재", 25f, Color.rgb(48, 45, 42), true)); title.addView(label("나만의 전자책 공간", 12f, muted))
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(button("＋ 책 추가") { chooseBook() }); add(root, top)
        val shelfHead = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = 0; setPadding(0, dp(24), 0, dp(12)) }
        shelfHead.addView(label("내 책  ${books.size}권", 13f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        shelfHead.addView(button("정렬 ▾") { chooseShelfSort() })
        add(root, shelfHead)
        val sc = ScrollView(this); val list = LinearLayout(this).apply { orientation = 1 }; sc.addView(list); root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        if (books.isEmpty()) list.addView(label("아직 책이 없어요\nEPUB 또는 TXT 파일을 추가해 보세요.", 16f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(90), 0, 0) })
        val orderedBooks = when (sortMode) {
            "title" -> books.withIndex().sortedBy { it.value.title.lowercase() }
            "author" -> books.withIndex().sortedBy { it.value.author.lowercase() }
            else -> books.withIndex().toList()
        }
        orderedBooks.forEach { indexed ->
            val i = indexed.index; val b = indexed.value
            val row = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(Color.WHITE, 14) }
            val coverFile = b.coverFileName?.let { File(bookDir(), it) }
            val bitmap = if (coverFile?.exists() == true) BitmapFactory.decodeFile(coverFile.absolutePath) else null
            if (bitmap != null) row.addView(ImageView(this).apply { setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(62), dp(86)))
            else row.addView(label("BOOK\n✦", 12f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = bg(intArrayOf(0xff8d8176.toInt(), 0xff788575.toInt(), 0xff88777b.toInt())[i % 3], 8) }, LinearLayout.LayoutParams(dp(62), dp(86)))
            val info = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, 0, 0) }
            info.addView(label(b.title, 15f, Color.rgb(48, 45, 42), true)); info.addView(label(b.author, 12f, muted).apply { setPadding(0, dp(5), 0, 0) })
            info.addView(label("책갈피 ${b.marks.size}개", 11f, accent).apply { setPadding(0, dp(8), 0, 0) })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); row.setOnClickListener { openBook(i) }; row.setOnLongClickListener { bookOptions(i); true }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); list.addView(row, lp)
        }
    }

    private fun chooseShelfSort() {
        val opts = arrayOf("최근 추가순", "제목 가나다순", "작가 가나다순")
        val selected = when (sortMode) { "title" -> 1; "author" -> 2; else -> 0 }
        AlertDialog.Builder(this).setTitle("서재 정렬").setSingleChoiceItems(opts, selected) { d, n ->
            sortMode = arrayOf("recent", "title", "author")[n]
            getSharedPreferences("library", MODE_PRIVATE).edit().putString("sort", sortMode).apply()
            d.dismiss(); showShelf()
        }.setNegativeButton("취소", null).show()
    }

    private fun bookOptions(i: Int) {
        AlertDialog.Builder(this).setTitle(books[i].title).setItems(arrayOf("책 정보 수정", "서재에서 삭제")) { _, n -> if (n == 0) editBook(i) else deleteBook(i) }.setNegativeButton("취소", null).show()
    }
    private fun deleteBook(i: Int) {
        val b = books[i]
        AlertDialog.Builder(this).setTitle("책 삭제").setMessage("'${b.title}'을(를) 앱 서재에서 삭제할까요? 앱에 보관된 파일도 삭제됩니다. 휴대폰 원본 파일은 삭제되지 않습니다.")
            .setPositiveButton("삭제") { _, _ ->
                File(bookDir(), b.storedFileName).delete(); b.coverFileName?.let { File(bookDir(), it).delete() }
                books.removeAt(i); saveBooks(); showShelf()
            }.setNegativeButton("취소", null).show()
    }
    private fun editBook(i: Int) {
        val b = books[i]; val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(20), 0, dp(20), 0) }
        val t = EditText(this).apply { setText(b.title); hint = "책 제목" }; val a = EditText(this).apply { setText(b.author); hint = "작가명" }
        box.addView(t); box.addView(a)
        AlertDialog.Builder(this).setTitle("책 정보 수정").setView(box).setPositiveButton("저장") { _, _ -> b.title = t.text.toString(); b.author = a.text.toString(); saveBooks(); showShelf() }.setNegativeButton("취소", null).show()
    }
    private fun chooseBook() {
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "text/plain", "application/octet-stream")) }
        startActivityForResult(it, pick)
    }
    @Deprecated("Deprecated") override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d); if (r != pick || c != RESULT_OK) return
        val u = d?.data ?: return
        val displayName = contentResolver.query(u, null, null, null, null)?.use { x ->
            val k = x.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (x.moveToFirst() && k >= 0) x.getString(k) else "새 책.txt"
        } ?: "새 책.txt"
        var copied: File? = null
        try {
            val epub = displayName.lowercase().endsWith(".epub"); val ext = if (epub) ".epub" else ".txt"
            val id = UUID.randomUUID().toString(); val stored = "$id$ext"; val dest = File(bookDir(), stored); copied = dest
            contentResolver.openInputStream(u)?.use { input -> FileOutputStream(dest).use { output -> input.copyTo(output) } } ?: throw Exception("파일을 열 수 없습니다.")
            val parsed = if (epub) parseEpub(dest, id) else ParsedBook(dest.readText(Charsets.UTF_8), emptyList(), null)
            val b = Book(id, displayName.substringBeforeLast('.'), "작가명", parsed.text, stored, parsed.coverFileName, parsed.chapters)
            books.add(0, b); saveBooks(); openBook(0)
            Toast.makeText(this, "책을 앱에 보관했어요. 원본을 삭제해도 읽을 수 있습니다.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            copied?.delete(); Toast.makeText(this, "책을 추가하지 못했습니다: ${e.message ?: "오류"}", Toast.LENGTH_LONG).show()
        }
    }

    private data class ParsedBook(val text: String, val chapters: List<Chapter>, val coverFileName: String?)
    private fun parseEpub(file: File, id: String = file.nameWithoutExtension): ParsedBook {
        ZipFile(file).use { zip ->
            fun readEntry(path: String): String = zip.getEntry(path)?.let { zip.getInputStream(it).bufferedReader(Charsets.UTF_8).use { r -> r.readText() } } ?: ""
            fun clean(html: String): String = html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>"), "\n\n")
                .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace(Regex("[ \\t]+"), " ").trim()
            val container = readEntry("META-INF/container.xml")
            val opfPath = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(container)?.groupValues?.get(1)
                ?: zip.entries().asSequence().firstOrNull { it.name.endsWith(".opf", true) }?.name
            if (opfPath == null) return ParsedBook("EPUB 목차 정보를 찾지 못했습니다.", emptyList(), null)
            val opf = readEntry(opfPath); val base = opfPath.substringBeforeLast('/', "")
            fun resolve(href: String) = if (base.isBlank()) href.substringBefore('#') else "$base/${href.substringBefore('#')}"
            val manifest = mutableMapOf<String, Pair<String, String>>()
            val itemRegex = Regex("<item\\b([^>]*)/?>", RegexOption.IGNORE_CASE)
            for (m in itemRegex.findAll(opf)) {
                val attrs = m.groupValues[1]
                val itemId = Regex("id=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val href = Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: continue
                val props = Regex("properties=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1) ?: ""
                manifest[itemId] = Pair(resolve(href), props)
            }
            var coverPath: String? = manifest.values.firstOrNull { it.second.split(' ').contains("cover-image") }?.first
            if (coverPath == null) {
                val coverId = Regex("<meta\\b[^>]*name=['\"]cover['\"][^>]*content=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(opf)?.groupValues?.get(1)
                if (coverId != null) coverPath = manifest[coverId]?.first
            }
            var coverName: String? = null
            if (coverPath != null) {
                val entry = zip.getEntry(coverPath)
                if (entry != null) {
                    val suffix = coverPath.substringAfterLast('.', "jpg").take(5)
                    coverName = "${id}_cover.$suffix"
                    zip.getInputStream(entry).use { input -> FileOutputStream(File(bookDir(), coverName)).use { output -> input.copyTo(output) } }
                }
            }
            val titleByHref = mutableMapOf<String, String>()
            val navItem = manifest.values.firstOrNull { it.second.split(' ').contains("nav") }?.first
            if (navItem != null) {
                val navHtml = readEntry(navItem)
                val navBase = navItem.substringBeforeLast('/', "")
                val navRegex = Regex("<a\\b[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                for (m in navRegex.findAll(navHtml)) {
                    val href = m.groupValues[1].substringBefore('#')
                    val full = if (href.startsWith("/")) href.removePrefix("/") else if (navBase.isBlank()) href else "$navBase/$href"
                    titleByHref[full] = clean(m.groupValues[2]).replace(Regex("\\s+"), " ").take(100)
                }
            }
            if (titleByHref.isEmpty()) {
                val ncxPath = manifest.values.firstOrNull { it.first.endsWith(".ncx", true) }?.first
                if (ncxPath != null) {
                    val ncx = readEntry(ncxPath); val ncxBase = ncxPath.substringBeforeLast('/', "")
                    val navPoint = Regex("<navPoint\\b.*?</navPoint>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    for (m in navPoint.findAll(ncx)) {
                        val href = Regex("<content\\b[^>]*src=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(m.value)?.groupValues?.get(1)?.substringBefore('#') ?: continue
                        val label = Regex("<text>(.*?)</text>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(m.value)?.groupValues?.get(1)?.let { clean(it) } ?: continue
                        val full = if (href.startsWith("/")) href.removePrefix("/") else if (ncxBase.isBlank()) href else "$ncxBase/$href"
                        titleByHref[full] = label
                    }
                }
            }
            val spine = Regex("<itemref\\b[^>]*idref=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).findAll(opf).mapNotNull { manifest[it.groupValues[1]]?.first }.toList()
            val chapters = spine.mapNotNull { path ->
                val html = readEntry(path); if (html.isBlank()) null else {
                    val title = titleByHref[path] ?: Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)?.let { clean(it) }?.take(100) ?: "본문 ${spine.indexOf(path) + 1}"
                    val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    Chapter(title, clean(body))
                }
            }
            val finalChapters = chapters.ifEmpty {
                zip.entries().asSequence().filter { !it.isDirectory && it.name.endsWith(".xhtml", true) }.mapNotNull { e ->
                    val html = readEntry(e.name); val body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
                    clean(body).takeIf { it.isNotBlank() }?.let { Chapter(e.name.substringAfterLast('/').substringBeforeLast('.'), it) }
                }.toList()
            }
            val text = finalChapters.joinToString("\n\n") { it.text }.ifBlank { "EPUB 본문을 찾지 못했습니다." }
            return ParsedBook(text, finalChapters, coverName)
        }
    }

    private fun openBook(i: Int) {
        if (i !in books.indices) return
        stopAuto(); stopTts(); current = i; root.removeAllViews(); root.setPadding(0, 0, 0, 0); root.setBackgroundColor(paper)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(paper) }
        top.addView(button("‹") { showShelf() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("⌕") { search() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("▤") { showBookmarkList() }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("♧") { bookmark() }, LinearLayout.LayoutParams(0, -2, 1f)); add(root, top)
        val w = WebView(this).apply {
            setBackgroundColor(paper); settings.javaScriptEnabled = true
            isVerticalScrollBarEnabled = !pageMode; isHorizontalScrollBarEnabled = false
            addJavascriptInterface(ReaderBridge(), "ReaderBridge")
        }
        web = w; root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        ttsPlayerBar = buildTtsPlayer().also { it.visibility = View.GONE; root.addView(it) }
        val bar = LinearLayout(this).apply { orientation = 0; setPadding(dp(4), dp(7), dp(4), dp(7)); setBackgroundColor(Color.rgb(35, 35, 37)) }
        val actions = listOf("목차", "TTS", "자동\n스크롤", "책갈피", "보기\n설정", "뷰어\n설정")
        actions.forEachIndexed { n, s -> bar.addView(button(s) { when (n) { 0 -> toc(); 1 -> ttsControls(); 2 -> toggleAuto(); 3 -> showBookmarkList(); 4 -> viewSettings(); 5 -> readerSettings() } }, LinearLayout.LayoutParams(0, -2, 1f)) }
        add(root, bar)
    }

    private fun markPage(raw: String): Int? = raw.removePrefix("page:").substringBefore("|").toIntOrNull()
    private fun markChapter(raw: String): String = raw.substringAfter("|chapter:", "").takeIf { it.isNotBlank() } ?: "본문"

    private fun render() {
        val b = books.getOrNull(current) ?: return
        val paragraphList = b.text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
        val chapterAt = mutableMapOf<Int, String>()
        var paragraphCursor = 0
        b.chapters.forEach { chapter ->
            chapterAt[paragraphCursor] = chapter.title
            paragraphCursor += chapter.text.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }
        }
        val paras = paragraphList.mapIndexed { idx, it ->
            val heading = chapterAt[idx]?.let { title -> "<h2 data-chapter=\"${esc(title)}\">${esc(title)}</h2>" } ?: ""
            heading + "<p id=\"para$idx\" data-para=\"$idx\">${esc(it).replace("\n", "<br>")}</p>"
        }.joinToString("")
        val bg = if (darkMode) "#232325" else "#F9F7F1"; val fg = if (darkMode) "#E8E5DE" else "#393630"
        val layout = if (pageMode) """
            html,body{width:100%;height:100%;overflow:hidden}
            body{width:100vw;height:100vh;overflow-x:auto;overflow-y:hidden;column-width:calc(100vw - 48px);column-gap:48px;column-fill:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;}
        """ else """
            html,body{min-height:100%;overflow-x:hidden;overflow-y:auto}
            body{column-width:auto}
        """
        val marked = b.marks.mapNotNull { markPage(it) }.distinct().joinToString(",")
        val html = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><style>
            *{box-sizing:border-box}html,body{margin:0;background:$bg;color:$fg}
            body{font-family:serif;font-size:${font}px;line-height:$line;padding:30px 24px 55px;word-break:keep-all;overflow-wrap:anywhere}
            h2{font-size:1.15em;margin:0 0 1.4em;font-weight:700;break-after:avoid}
            p{margin:0 0 1.6em;text-align:justify;break-inside:avoid}
            #bookmarkRibbon{position:fixed;z-index:99;right:12px;top:0;width:24px;height:48px;background:#c62828;clip-path:polygon(0 0,100% 0,100% 100%,50% 78%,0 100%);display:none}
            .ttsCurrent{background:#f5df70;color:#29251d;border-radius:3px}
            $layout
        </style></head><body>$paras<div id="bookmarkRibbon"></div>
        <script>
        const markedPages=[$marked];
        function pageIndex(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/(window.innerWidth)))" else "Math.max(0,Math.floor(window.scrollY/Math.max(1,window.innerHeight)))"};}
        function updateRibbon(){document.getElementById('bookmarkRibbon').style.display=markedPages.includes(pageIndex())?'block':'none';}
        function goPage(n){if(${pageMode})document.body.scrollTo({left:n*window.innerWidth,behavior:'auto'});else window.scrollTo({top:n*window.innerHeight,behavior:'auto'});updateRibbon();}
        function currentChapterTitle(){
          const heads=Array.from(document.querySelectorAll('h2[data-chapter]'));
          let found='본문';
          for(const h of heads){const r=h.getBoundingClientRect();const passed=${pageMode}?(r.left < window.innerWidth):(r.top < window.innerHeight);if(passed)found=h.dataset.chapter;else break;}
          return found;
        }
        function currentPageText(){
          if(${pageMode}){const w=window.innerWidth;return Array.from(document.querySelectorAll('p')).filter(p=>{const r=p.getBoundingClientRect();return r.right>0&&r.left<w;}).map(p=>p.innerText).join('\n');}
          const y=window.scrollY;const h=window.innerHeight;return Array.from(document.querySelectorAll('p')).filter(p=>{const r=p.getBoundingClientRect();return r.bottom>0&&r.top<h;}).map(p=>p.innerText).join('\n');
        }
        function highlightText(t){document.querySelectorAll('.ttsCurrent').forEach(e=>e.classList.remove('ttsCurrent'));const p=Array.from(document.querySelectorAll('p')).find(e=>e.innerText.includes(t.slice(0,Math.min(18,t.length))));if(p){p.classList.add('ttsCurrent');if(${pageMode}){const left=p.getBoundingClientRect().left+document.body.scrollLeft;const target=Math.max(0,Math.floor(left/window.innerWidth));document.body.scrollTo({left:target*window.innerWidth,behavior:'auto'});}else{p.scrollIntoView({block:'center'});}}}
        if(${pageMode}){
          let sx=0,sy=0;
          document.addEventListener('touchstart',e=>{if(e.touches.length===1){sx=e.touches[0].clientX;sy=e.touches[0].clientY;}},{passive:true});
          document.addEventListener('touchend',e=>{if(!e.changedTouches.length)return;const dx=e.changedTouches[0].clientX-sx;const dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){const w=window.innerWidth;const next=Math.max(0,Math.round(document.body.scrollLeft/w)+(dx<0?1:-1));document.body.scrollTo({left:next*w,behavior:'smooth'});setTimeout(updateRibbon,220);}},{passive:true});
        }
        window.addEventListener('scroll',updateRibbon);window.addEventListener('resize',updateRibbon);setTimeout(updateRibbon,100);
        </script></body></html>"""
        web?.setBackgroundColor(paper)
        web?.isVerticalScrollBarEnabled = !pageMode
        web?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private inner class ReaderBridge {
        @JavascriptInterface fun onPageChanged(page: Int) { runOnUiThread { /* reserved for reader position persistence */ } }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun bookmark() {
        val b = books.getOrNull(current) ?: return
        web?.evaluateJavascript("""(function(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/window.innerWidth))" else "Math.max(0,Math.floor(window.scrollY/window.innerHeight))"};})()""") { value ->
            val page = value?.trim('"')?.toIntOrNull() ?: 0
            web?.evaluateJavascript("currentChapterTitle()") { titleRaw ->
                val chapter = try { (org.json.JSONTokener(titleRaw ?: "\"본문\"").nextValue() as? String) ?: "본문" } catch (_: Exception) { "본문" }
                val old = b.marks.firstOrNull { markPage(it) == page }
                if (old != null) b.marks.remove(old) else b.marks.add("page:$page|chapter:${chapter.replace("|", " ")}")
                saveBooks(); render()
                web?.evaluateJavascript("setTimeout(()=>goPage($page),180)", null)
                Toast.makeText(this, if (old == null) "이 페이지를 책갈피에 추가했어요" else "책갈피를 해제했어요", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun showBookmarkList() {
        val b = books.getOrNull(current) ?: return
        val entries = b.marks.mapNotNull { raw -> markPage(raw)?.let { page -> Triple(page, markChapter(raw), raw) } }.distinctBy { it.first }.sortedBy { it.first }.map { mark ->
            val page = mark.first
            val note = b.notes.firstOrNull { raw ->
                val o = runCatching { JSONObject(raw) }.getOrNull(); o?.optInt("page", -1) == page
            }?.let { runCatching { JSONObject(it).optString("text") }.getOrNull() }
            Triple(page, "${mark.second} · ${page + 1}페이지", note)
        }
        if (entries.isEmpty()) { AlertDialog.Builder(this).setTitle("책갈피").setMessage("저장된 책갈피가 없습니다.").setPositiveButton("확인", null).show(); return }
        val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val scroll = ScrollView(this); scroll.addView(box)
        var dialogRef: AlertDialog? = null
        entries.forEach { item ->
            val card = LinearLayout(this).apply { orientation = 1; setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(if (darkMode) Color.rgb(55,55,57) else Color.rgb(248,246,241), 8) }
            card.addView(label("${item.second}", 15f, ink, true))
            if (!item.third.isNullOrBlank()) card.addView(label("✉️ ${item.third}", 13f, muted).apply { setPadding(0, dp(6), 0, 0) })
            card.setOnClickListener { web?.evaluateJavascript("goPage(${item.first})", null); dialogRef?.dismiss() }
            card.setOnLongClickListener {
                val opts = arrayOf("이 페이지로 이동", "메모 추가/수정", "책갈피 삭제")
                AlertDialog.Builder(this).setItems(opts) { _, which -> when(which) {
                    0 -> web?.evaluateJavascript("goPage(${item.first})", null)
                    1 -> editBookmarkNote(item.first)
                    2 -> { b.marks.removeAll { markPage(it) == item.first }; b.notes.removeAll { runCatching { JSONObject(it).optInt("page", -1) == item.first }.getOrDefault(false) }; saveBooks(); showBookmarkList() }
                } }.show(); true
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); box.addView(card, lp)
        }
        dialogRef = AlertDialog.Builder(this).setTitle("책갈피 ${entries.size}개 · 길게 눌러 편집").setView(scroll).setPositiveButton("닫기", null).create()
        dialogRef?.show()
    }

    private fun editBookmarkNote(page: Int) {
        val b = books.getOrNull(current) ?: return
        val idx = b.notes.indexOfFirst { runCatching { JSONObject(it).optInt("page", -1) == page }.getOrDefault(false) }
        val old = if (idx >= 0) runCatching { JSONObject(b.notes[idx]).optString("text") }.getOrDefault("") else ""
        val edit = EditText(this).apply { hint = "이 책갈피에 메모"; minLines = 3; setText(old) }
        AlertDialog.Builder(this).setTitle("${page + 1}페이지 메모").setView(edit).setPositiveButton("저장") { _, _ ->
            val value = edit.text.toString().trim()
            if (idx >= 0) b.notes.removeAt(idx)
            if (value.isNotBlank()) b.notes.add(JSONObject().put("page", page).put("text", value).toString())
            saveBooks()
        }.setNegativeButton("취소", null).show()
    }

    private fun search() { val e = EditText(this).apply { hint = "검색할 내용" }; AlertDialog.Builder(this).setTitle("책 속 내용 검색").setView(e).setPositiveButton("검색") { _, _ -> web?.findAllAsync(e.text.toString()) }.setNegativeButton("취소", null).show() }

    private fun toc() {
        val b = books.getOrNull(current) ?: return
        if (b.chapters.isNotEmpty()) {
            val entries = b.chapters.map { it.title }.toTypedArray()
            AlertDialog.Builder(this).setTitle("EPUB 원본 목차").setItems(entries) { _, which ->
                val target = b.chapters.take(which).sumOf { it.text.split(Regex("\\n\\s*\\n")).count { p -> p.isNotBlank() } }
                web?.evaluateJavascript("document.getElementById('para$target')?.scrollIntoView();", null)
            }.setNegativeButton("닫기", null).show()
        } else {
            AlertDialog.Builder(this).setTitle("목차").setMessage("이 TXT 파일에는 원본 목차가 없습니다.").setPositiveButton("확인", null).show()
        }
    }
    private fun notes() {
        val b = books.getOrNull(current) ?: return
        fun pageNow(done: (Int) -> Unit) {
            web?.evaluateJavascript("""(function(){return ${if (pageMode) "Math.max(0,Math.round(document.body.scrollLeft/window.innerWidth))" else "Math.max(0,Math.floor(window.scrollY/window.innerHeight))"};})()""") { v -> done(v?.trim('"')?.toIntOrNull() ?: 0) }
        }
        fun showNotes() {
            val parsed = b.notes.mapIndexed { i, raw ->
                try { val o = JSONObject(raw); Pair(o.optInt("page", 0), o.optString("text")) }
                catch (_: Exception) { Pair(0, raw) }
            }
            val labels = parsed.mapIndexed { i, item -> "${i + 1}. ${if (item.first > 0) "${item.first + 1}쪽 · " else ""}${item.second}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("독서노트 · ${b.notes.size}개")
                .setItems(labels.ifEmpty { arrayOf("저장된 메모가 없습니다.") }) { _, which ->
                    if (which < b.notes.size) editNote(which)
                }
                .setPositiveButton("메모 추가") { _, _ -> pageNow { page ->
                    val e = EditText(this).apply { hint = "메모를 입력하세요"; minLines = 3 }
                    AlertDialog.Builder(this).setTitle("${page + 1}쪽 메모 추가").setView(e)
                        .setPositiveButton("저장") { _, _ ->
                            val value = e.text.toString().trim(); if (value.isNotEmpty()) {
                                b.notes.add(JSONObject().put("page", page).put("text", value).toString()); saveBooks()
                            }
                        }.setNegativeButton("취소", null).show()
                } }.setNegativeButton("닫기", null).show()
        }
        showNotes()
    }

    private fun editNote(index: Int) {
        val b = books.getOrNull(current) ?: return
        if (index !in b.notes.indices) return
        val raw = b.notes[index]
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("page", 0).put("text", raw) }
        val e = EditText(this).apply { hint = "메모를 입력하세요"; minLines = 3; setText(obj.optString("text")) }
        AlertDialog.Builder(this).setTitle("독서 메모 수정").setView(e)
            .setPositiveButton("저장") { _, _ ->
                val value = e.text.toString().trim()
                if (value.isBlank()) b.notes.removeAt(index)
                else b.notes[index] = JSONObject().put("page", obj.optInt("page", 0)).put("text", value).toString()
                saveBooks()
            }.setNeutralButton("삭제") { _, _ ->
                AlertDialog.Builder(this).setMessage("이 메모를 삭제할까요?").setPositiveButton("삭제") { _, _ -> b.notes.removeAt(index); saveBooks() }.setNegativeButton("취소", null).show()
            }.setNegativeButton("취소", null).show()
    }

    private fun buildTtsPlayer(): LinearLayout {
        val panel = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(if (darkMode) Color.rgb(28,28,30) else Color.rgb(235,231,223)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(button("|◀") { if (aiIndex > 0) { aiIndex = (aiIndex - 1).coerceAtLeast(0); playAiChunks() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button(if (aiPaused) "▶" else "Ⅱ") { if (aiPaused) resumeAiTts() else pauseAiTts(); updateTtsPlayer() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("▶| ") { if (aiIndex < aiChunks.lastIndex) { aiIndex++; playAiChunks() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("■") { stopTts() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button(selectedVoice) { chooseAiVoice() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("${aiSpeed}×") { chooseAiSpeed() }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(row)
        panel.addView(label("Supertonic · 남성 AI 음성", 11f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        return panel
    }

    private fun updateTtsPlayer() {
        ttsPlayerBar?.visibility = if (aiChunks.isNotEmpty() || aiPlaybackJob?.isActive == true) View.VISIBLE else View.GONE
        val bar = ttsPlayerBar ?: return
        val fresh = buildTtsPlayer()
        bar.removeAllViews()
        while (fresh.childCount > 0) {
            val child = fresh.getChildAt(0)
            fresh.removeViewAt(0)
            bar.addView(child)
        }
    }

    private fun ttsControls() {
        val options = arrayOf("현재 페이지부터 AI 음성으로 읽기", "일시정지", "이어 읽기", "남성 목소리 선택 (현재 $selectedVoice)", "읽기 속도 설정", "읽기 중지")
        AlertDialog.Builder(this).setTitle("AI 책 읽어주기 · Supertonic")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startAiTts(true)
                    1 -> pauseAiTts()
                    2 -> resumeAiTts()
                    3 -> chooseAiVoice()
                    4 -> chooseAiSpeed()
                    5 -> stopTts()
                }
            }.setNegativeButton("닫기", null).show()
    }

    private fun chooseAiVoice() {
        val voices = arrayOf("M1", "M2", "M3", "M4", "M5")
        AlertDialog.Builder(this).setTitle("남성 AI 목소리 선택")
            .setSingleChoiceItems(voices, voices.indexOf(selectedVoice).coerceAtLeast(0)) { dialog, which ->
                selectedVoice = voices[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putString("voice", selectedVoice).apply()
                dialog.dismiss(); updateTtsPlayer()
                Toast.makeText(this, "$selectedVoice 목소리로 설정했어요.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("취소", null).show()
    }

    private fun chooseAiSpeed() {
        val speeds = floatArrayOf(0.8f, 0.9f, 1.0f, 1.05f, 1.2f, 1.35f)
        val labels = arrayOf("0.8배", "0.9배", "1.0배", "1.05배", "1.2배", "1.35배")
        val selected = speeds.indices.minByOrNull { kotlin.math.abs(speeds[it] - aiSpeed) } ?: 3
        AlertDialog.Builder(this).setTitle("읽기 속도")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                aiSpeed = speeds[which]
                getSharedPreferences("ai_tts", MODE_PRIVATE).edit().putFloat("speed", aiSpeed).apply()
                dialog.dismiss(); updateTtsPlayer()
            }.setNegativeButton("취소", null).show()
    }

    private fun startAiTts(restart: Boolean) {
        val book = books.getOrNull(current) ?: return
        if (restart) {
            web?.evaluateJavascript("currentPageText()") { raw ->
                val visible = try { org.json.JSONTokener(raw ?: "\"\"").nextValue() as? String ?: "" } catch (_: Exception) { "" }
                val anchor = visible.trim().take(36)
                val startAt = if (anchor.isNotBlank()) book.text.indexOf(anchor).takeIf { it >= 0 } ?: 0 else 0
                val source = if (visible.isBlank()) book.text else book.text.substring(startAt)
                aiChunks = splitForSpeech(source)
                aiIndex = 0
                aiPaused = false
                ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
            }
            return
        }
        if (aiChunks.isEmpty()) aiChunks = splitForSpeech(book.text)
        aiPaused = false
        ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
    }

    private fun splitForSpeech(text: String): List<String> {
        // Join paragraph boundaries so the reader does not insert a deliberate pause between paragraphs.
        val normalized = text.replace(Regex("\\s+"), " ").trim()
        val sentences = normalized.split(Regex("(?<=[.!?。！？])\\s*")).filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        var group = StringBuilder()
        for (sentence in sentences) {
            if (group.isNotEmpty() && group.length + sentence.length > 220) {
                out.add(group.toString().trim()); group = StringBuilder()
            }
            if (group.isNotEmpty()) group.append(" ")
            group.append(sentence)
        }
        if (group.isNotEmpty()) out.add(group.toString().trim())
        return out
    }

    private fun resumeAiTts() {
        if (aiChunks.isEmpty()) { startAiTts(true); return }
        aiPaused = false
        ensureAiEngine { updateTtsPlayer(); if (aiIndex < aiChunks.size) playAiChunks() }
    }

    private fun pauseAiTts() {
        aiPaused = true
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        updateTtsPlayer(); stopPlaybackService(); Toast.makeText(this, "일시정지했어요.", Toast.LENGTH_SHORT).show()
    }

    private fun playAiChunks() {
        val engine = aiEngine ?: return
        startPlaybackService()
        aiPlaybackJob?.cancel()
        aiPlaybackJob = aiScope.launch {
            try {
                while (!aiPaused && aiIndex < aiChunks.size) {
                    val chunk = aiChunks[aiIndex]
                    runOnUiThread { web?.evaluateJavascript("highlightText(${JSONObject.quote(chunk)})", null) }
                    val pcm = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val style = com.ouor.supertonic.tts.VoiceStyle.load(
                            com.ouor.supertonic.data.ModelAssets.voiceStyleFile(this@MainActivity, selectedVoice)
                        )
                        engine.synthesize(chunk, "ko", style, totalStep = 8, speed = aiSpeed).wav
                    }
                    aiPlayer?.play(pcm, null)
                    aiIndex++
                    runOnUiThread { updateTtsPlayer() }
                }
                if (aiIndex >= aiChunks.size) {
                    aiChunks = emptyList(); aiIndex = 0
                    runOnUiThread { stopPlaybackService(); handler.postDelayed({ updateTtsPlayer() }, 150) }
                    web?.evaluateJavascript("document.querySelectorAll('.ttsCurrent').forEach(e=>e.classList.remove('ttsCurrent'))", null)
                    Toast.makeText(this@MainActivity, "읽기가 끝났어요.", Toast.LENGTH_SHORT).show()
                }
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Pause/stop requested by the user.
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "AI 음성 재생 오류: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun ensureAiEngine(onReady: () -> Unit) {
        if (aiEngine != null) { onReady(); return }
        if (!com.ouor.supertonic.data.ModelAssets.isReady(this)) {
            AlertDialog.Builder(this).setTitle("AI 음성 모델 다운로드")
                .setMessage("처음 한 번만 약 400MB의 음성 모델을 다운로드합니다. 이후에는 인터넷 없이 사용할 수 있어요. Wi-Fi 연결을 권장합니다.")
                .setPositiveButton("다운로드") { _, _ -> downloadAiModel(onReady) }
                .setNegativeButton("취소", null).show()
        } else loadAiEngine(onReady)
    }

    private fun downloadAiModel(onReady: () -> Unit) {
        val progress = android.app.ProgressDialog(this).apply {
            setTitle("AI 음성 모델 다운로드")
            setMessage("다운로드 준비 중...")
            setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
            max = 100; setCancelable(false); show()
        }
        aiScope.launch {
            var completed = false
            try {
                com.ouor.supertonic.data.ModelDownloader(this@MainActivity).download().collect { state ->
                    when (state) {
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Running -> {
                            val percent = if (state.totalBytes > 0) ((state.downloadedBytes * 100) / state.totalBytes).toInt() else 0
                            progress.progress = percent
                            progress.setMessage("파일 ${state.fileIndex + 1}/${state.fileCount} 다운로드 중... $percent%")
                        }
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Done -> completed = true
                        is com.ouor.supertonic.data.ModelDownloader.Progress.Failed -> throw IllegalStateException(state.message)
                    }
                }
                progress.dismiss()
                if (!completed) throw IllegalStateException("다운로드가 완료되지 않았습니다.")
                loadAiEngine(onReady)
            } catch (e: Exception) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, "모델 다운로드 실패: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadAiEngine(onReady: () -> Unit) {
        Toast.makeText(this, "AI 음성 엔진을 준비하고 있어요.", Toast.LENGTH_SHORT).show()
        aiScope.launch {
            try {
                val engine = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.ouor.supertonic.tts.SupertonicTts.load(com.ouor.supertonic.data.ModelAssets.onnxDir(this@MainActivity))
                }
                aiEngine?.close()
                aiEngine = engine
                aiPlayer = com.ouor.supertonic.audio.PcmPlayer(engine.sampleRate)
                onReady()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "AI 음성 엔진 오류: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startPlaybackService() {
        val intent = Intent(this, TtsPlaybackService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun stopPlaybackService() { stopService(Intent(this, TtsPlaybackService::class.java)) }

    private fun stopTts() {
        aiPaused = false
        aiPlaybackJob?.cancel()
        aiPlayer?.stop()
        aiChunks = emptyList(); aiIndex = 0
        ttsPlayerBar?.visibility = View.GONE
        stopPlaybackService()
    }

    private fun stopAuto() { auto = false; handler.removeCallbacks(autoTask) }
    private fun toggleAuto() {
        auto = !auto
        if (auto) handler.post(autoTask) else handler.removeCallbacks(autoTask)
        Toast.makeText(this, if (auto) "자동 스크롤 켜짐" else "자동 스크롤 꺼짐", Toast.LENGTH_SHORT).show()
    }
    private fun viewSettings() {
        val opts = arrayOf("페이지 넘김", "세로 스크롤", if (darkMode) "아이보리 모드로 전환" else "다크모드로 전환")
        AlertDialog.Builder(this).setTitle("읽기 방식 및 화면")
            .setSingleChoiceItems(opts, if (pageMode) 0 else 1) { d, n ->
                when (n) { 0 -> pageMode = true; 1 -> pageMode = false; 2 -> { darkMode = !darkMode; getSharedPreferences("reader", MODE_PRIVATE).edit().putBoolean("dark", darkMode).apply() } }
                render(); d.dismiss()
            }.show()
    }
    private fun readerSettings() {
        val opts = arrayOf("글자 크기 줄이기", "글자 크기 키우기", "줄 간격 변경")
        AlertDialog.Builder(this).setTitle("보기 설정").setItems(opts) { _, n ->
            when (n) { 0 -> font = (font - 1).coerceAtLeast(14); 1 -> font = (font + 1).coerceAtMost(32); 2 -> line = if (line < 2.0) 2.2 else 1.7 }
            render()
        }.show()
    }

    override fun onBackPressed() { if (web != null) showShelf() else super.onBackPressed() }
    override fun onDestroy() {
        stopAuto(); stopTts(); aiScope.cancel(); aiEngine?.close(); aiPlayer?.stop(); web?.destroy(); super.onDestroy()
    }
}
