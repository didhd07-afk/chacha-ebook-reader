# 차차의 서재 - Android project

Android EPUB/TXT reader project. Build with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and Java 17.

## Included in this revision

- EPUB/TXT import and bookshelf
- Shelf sorting: recent addition, title, and author (selection is saved)
- Ivory/dark reader themes and font/line settings
- Vertical scrolling and horizontal column page-turn mode
- Bookmark list with chapter title and page number
- Notes attached to bookmark entries; long-press a bookmark to add/edit/delete its note
- Supertonic offline Korean TTS integration with M1-M5 voice selection
- Bottom TTS player controls: previous chunk, play/pause, next chunk, stop, voice, and speed
- Current TTS paragraph highlighting
- Foreground media-playback service notification while TTS is playing, to help playback continue in the background

## Build

The repository workflow `.github/workflows/build-apk.yml` installs Gradle 8.9 and builds `assembleDebug` using Java 17. Upload this project ZIP to the repository root and run the workflow.

The first TTS use downloads the Supertonic model files (about 400 MB); afterward the model can be used offline. Model download requires an internet connection.

## Verification note

This source revision was edited in this environment, but a full Android Gradle build and on-device test were not available here. Run the GitHub Actions build and test the resulting APK on the target phone before relying on background playback and page-turn behavior.
